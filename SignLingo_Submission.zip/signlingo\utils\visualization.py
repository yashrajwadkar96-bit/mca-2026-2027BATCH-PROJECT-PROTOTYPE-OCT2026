"""
signlingo.utils.visualization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Publication-quality plotting for training curves, confusion matrices,
and multi-model benchmark comparisons.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Optional
from pathlib import Path


# Use a clean, modern style
plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "#fafafa",
    "axes.grid": True,
    "grid.alpha": 0.3,
    "font.family": "sans-serif",
    "font.size": 11,
})

# Default color palette
_PALETTE = ["#2196F3", "#FF5722", "#4CAF50", "#FF9800", "#9C27B0"]


def plot_training_history(
    history,
    save_path: Optional[str] = None,
    figsize: tuple = (14, 5),
):
    """
    Plot training vs. validation accuracy and loss curves.

    Parameters
    ----------
    history : keras History object or dict
        Must contain keys: ``accuracy``, ``val_accuracy``, ``loss``, ``val_loss``.
    save_path : str, optional
        If provided, save the figure to this path.
    """
    h = history.history if hasattr(history, "history") else history

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

    epochs = range(1, len(h["accuracy"]) + 1)

    # Accuracy
    ax1.plot(epochs, h["accuracy"],     label="Train",      linewidth=2, color=_PALETTE[0])
    ax1.plot(epochs, h["val_accuracy"], label="Validation", linewidth=2, color=_PALETTE[1])
    ax1.set_title("Model Accuracy", fontsize=14, fontweight="bold")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy")
    ax1.legend(frameon=True, fancybox=True, shadow=True)
    ax1.set_ylim(0, 1.05)

    # Loss
    ax2.plot(epochs, h["loss"],     label="Train",      linewidth=2, color=_PALETTE[0])
    ax2.plot(epochs, h["val_loss"], label="Validation", linewidth=2, color=_PALETTE[1])
    ax2.set_title("Model Loss", fontsize=14, fontweight="bold")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Loss")
    ax2.legend(frameon=True, fancybox=True, shadow=True)

    plt.tight_layout()

    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  📊 Saved: {save_path}")

    plt.close(fig)


def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: List[str],
    save_path: Optional[str] = None,
    figsize: tuple = (12, 10),
    title: str = "Confusion Matrix",
):
    """
    Plot a colour-coded confusion matrix with annotations.
    """
    from sklearn.metrics import confusion_matrix

    cm = confusion_matrix(y_true, y_pred)

    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=class_names, yticklabels=class_names,
        cbar_kws={"label": "Count"}, ax=ax,
    )
    ax.set_title(title, fontsize=16, fontweight="bold", pad=20)
    ax.set_ylabel("True Label", fontsize=12)
    ax.set_xlabel("Predicted Label", fontsize=12)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()

    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  📊 Saved: {save_path}")

    plt.close(fig)


def plot_model_comparison(
    results: Dict[str, dict],
    save_path: Optional[str] = None,
    figsize: tuple = (14, 6),
):
    """
    Plot a multi-model benchmark comparison chart.

    Parameters
    ----------
    results : dict
        Mapping ``model_name → {"accuracy": float, "top3_accuracy": float,
        "params": int, "epochs": int}``.
    save_path : str, optional
    """
    model_names = list(results.keys())
    accuracies = [results[m]["accuracy"] * 100 for m in model_names]
    top3_accs  = [results[m].get("top3_accuracy", 0) * 100 for m in model_names]
    params     = [results[m].get("params", 0) for m in model_names]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

    # Bar chart — accuracy comparison
    x = np.arange(len(model_names))
    width = 0.35

    bars1 = ax1.bar(x - width / 2, accuracies, width, label="Top-1 Accuracy",
                    color=_PALETTE[0], edgecolor="white", linewidth=0.8)
    bars2 = ax1.bar(x + width / 2, top3_accs, width, label="Top-3 Accuracy",
                    color=_PALETTE[1], edgecolor="white", linewidth=0.8)

    ax1.set_title("Model Accuracy Comparison", fontsize=14, fontweight="bold")
    ax1.set_xlabel("Architecture")
    ax1.set_ylabel("Accuracy (%)")
    ax1.set_xticks(x)
    ax1.set_xticklabels(model_names, rotation=15, ha="right")
    ax1.legend(frameon=True, fancybox=True, shadow=True)
    ax1.set_ylim(0, 105)

    # Add value labels on bars
    for bar in bars1:
        h = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2, h + 1,
                 f"{h:.1f}%", ha="center", va="bottom", fontsize=9, fontweight="bold")
    for bar in bars2:
        h = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2, h + 1,
                 f"{h:.1f}%", ha="center", va="bottom", fontsize=9, fontweight="bold")

    # Scatter — accuracy vs parameters (bubble chart)
    sizes = [max(p / 5000, 50) for p in params]
    colors = _PALETTE[: len(model_names)]
    for i, m in enumerate(model_names):
        ax2.scatter(
            params[i] / 1000, accuracies[i], s=sizes[i],
            color=colors[i], edgecolors="black", linewidths=0.5,
            label=m, zorder=5,
        )
    ax2.set_title("Accuracy vs Model Size", fontsize=14, fontweight="bold")
    ax2.set_xlabel("Parameters (K)")
    ax2.set_ylabel("Top-1 Accuracy (%)")
    ax2.legend(frameon=True, fancybox=True, shadow=True)

    plt.tight_layout()

    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  📊 Saved: {save_path}")

    plt.close(fig)
