#!/usr/bin/env python3
"""
Live ASL fingerspelling demo.

The original webcam script expected word-level weights (WLASL) and the
MediaPipe 0.x ``mp.solutions.hands`` API. Those weights are not in this
download, and MediaPipe 1.x removed that API. This demo uses the trained
alphabet CNN plus the Tasks hand landmarker.

Keys
----
    Space       insert a space
    Backspace   delete the last character
    F           if the spelled words are known glosses, show an English sentence
    C           clear the spelled text
    S           save a screenshot
    Q           quit
"""

from __future__ import annotations

import os
import sys
import time
from collections import deque

import cv2

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.data.hands_runtime import HandTracker, draw_hands
from signlingo.history_store import PredictionHistory
from signlingo.models.landmark_alphabet import predict_landmarks
from signlingo.sentence.formation import SentenceFormer, _POS_MAP
from signlingo.sentence.spelling import SpellingBuffer

GREEN = (80, 220, 120)
YELLOW = (0, 220, 220)
RED = (60, 60, 220)
WHITE = (245, 245, 245)
DARK = (22, 24, 28)
BLUE = (230, 170, 80)
GRAY = (150, 150, 150)
FONT = cv2.FONT_HERSHEY_SIMPLEX


def _alpha_rect(frame, x1, y1, x2, y2, color, alpha=0.78):
    overlay = frame.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
    cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)


def _bar(frame, x, y, w, h, value, color):
    fill = int(w * min(max(value, 0.0), 1.0))
    cv2.rectangle(frame, (x, y), (x + fill, y + h), color, -1)
    cv2.rectangle(frame, (x, y), (x + w, y + h), GRAY, 1)


def draw_panel(frame, letter, confidence, stability, spelled, english, fps, hands):
    h, w = frame.shape[:2]
    _alpha_rect(frame, 0, 0, w, 168, DARK)
    color = GREEN if confidence >= 0.55 else YELLOW if confidence > 0.35 else RED
    cv2.putText(frame, letter, (18, 48), FONT, 1.4, color, 2, cv2.LINE_AA)
    _bar(frame, 90, 28, min(360, w - 280), 18, confidence, color)
    cv2.putText(frame, f"{confidence * 100:.0f}%", (w - 150, 46), FONT, 0.7, WHITE, 2, cv2.LINE_AA)
    cv2.putText(frame, "stable", (18, 82), FONT, 0.45, GRAY, 1, cv2.LINE_AA)
    _bar(frame, 90, 70, 160, 12, stability, BLUE)
    shown = spelled if spelled else "—"
    cv2.putText(frame, f"Spelled: {shown}", (18, 114), FONT, 0.7, WHITE, 2, cv2.LINE_AA)
    if english:
        cv2.putText(frame, english[:80], (18, 146), FONT, 0.55, BLUE, 1, cv2.LINE_AA)
    hands_text = "  ".join(hands) if hands else "no hand"
    cv2.putText(frame, f"{hands_text}    {fps:.0f} fps", (w - 280, 146), FONT, 0.48, GRAY, 1, cv2.LINE_AA)
    _alpha_rect(frame, 0, h - 36, w, h, DARK, 0.7)
    cv2.putText(
        frame,
        "Space=word   Backspace=delete   F=English if gloss   C=clear   S=shot   Q=quit",
        (12, h - 12),
        FONT,
        0.45,
        WHITE,
        1,
        cv2.LINE_AA,
    )


def main():
    print("SignLingo fingerspelling demo")
    print("Loading the hand landmarker...")
    print("Palm toward the camera, fingers pointing up.")
    tracker = HandTracker(mode="video", max_hands=1, min_detection_confidence=0.6)
    spelling = SpellingBuffer()
    history = PredictionHistory()
    former = SentenceFormer()
    recent = deque(maxlen=8)
    english = ""

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open a webcam. Use the Streamlit app to upload a photo instead.")
        tracker.close()
        return 1
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    letter, confidence, stability = "—", 0.0, 0.0
    frames = 0
    t0 = time.time()
    print("Webcam open. Press Q to quit.")

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        detection = tracker.detect(frame)
        draw_hands(frame, detection)

        if detection.hands:
            letter, confidence, _probs = predict_landmarks(detection.hands[0].landmarks)
            recent.append(letter)
            top = max(set(recent), key=list(recent).count)
            stability = list(recent).count(top) / len(recent)
            committed = spelling.observe(letter, confidence, stability, threshold=0.7)
            if committed:
                history.add(committed, confidence, source="webcam")
                english = ""
        else:
            letter, confidence, stability = "—", 0.0, 0.0
            recent.clear()
            spelling.observe("", 0.0, 0.0)

        frames += 1
        fps = frames / (time.time() - t0 + 1e-9)
        draw_panel(
            frame, letter, confidence, stability, spelling.text, english, fps, detection.labels()
        )
        cv2.imshow("SignLingo", frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), ord("Q")):
            break
        if key == ord(" "):
            spelling.space()
        elif key in (8, 127):
            spelling.backspace()
            english = ""
        elif key in (ord("c"), ord("C")):
            spelling.clear()
            english = ""
            recent.clear()
        elif key in (ord("s"), ord("S")):
            name = f"screenshot_{time.strftime('%Y%m%d_%H%M%S')}.png"
            cv2.imwrite(name, frame)
            print("saved", name)
        elif key in (ord("f"), ord("F")):
            tokens = spelling.tokens()
            if tokens and all(tok in _POS_MAP for tok in tokens):
                english = former.form_sentence(tokens)
                print("English:", english)
            else:
                english = ""
                print("Spelled text is not a sequence of known word glosses:", spelling.text)

    cap.release()
    cv2.destroyAllWindows()
    tracker.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
