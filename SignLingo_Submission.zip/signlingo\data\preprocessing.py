"""
signlingo.data.preprocessing
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Data augmentation for hand-landmark time-series.

New augmentations over v1
--------------------------
* ``random_rotation_2d`` — rotates the (x, y) plane of every landmark by a
  small random angle, simulating wrist roll / camera tilt variation.
* ``speed_variation`` — resamples the sequence at a randomly stretched or
  compressed speed, producing temporal variability beyond simple shifts.
* Dual-hand-aware ``mirror_x`` — when ``use_both_hands`` is active, mirroring
  also *swaps* the left and right hand slots so the semantics stay correct.
* Augmentation probability raised to **0.5** (was 0.3) for better coverage
  on small datasets.
"""

import numpy as np
from typing import Tuple, Optional

from signlingo.config import SignLingoConfig, get_config


class DataAugmentor:
    """
    Augmentation suite for landmark-based sign language sequences.

    All methods operate on ``(T, D)`` arrays where *T* is the temporal
    dimension and *D* is the landmark feature dimension.

    Parameters
    ----------
    config : SignLingoConfig, optional
        Source of augmentation hyper-parameters.
    """

    def __init__(self, config: Optional[SignLingoConfig] = None):
        self.cfg = config or get_config()

    # ──────────────────────────────────────────────────────────────────────
    # Original augmentations (preserved, minor improvements)
    # ──────────────────────────────────────────────────────────────────────

    def add_gaussian_noise(self, seq: np.ndarray) -> np.ndarray:
        """Add Gaussian noise ~ N(0, noise_factor) to the sequence."""
        noise = np.random.normal(0, self.cfg.noise_factor, seq.shape)
        return seq + noise

    def random_scale(self, seq: np.ndarray) -> np.ndarray:
        """Scale all coordinates by a uniform random factor."""
        lo, hi = self.cfg.scale_range
        factor = np.random.uniform(lo, hi)
        return seq * factor

    def temporal_shift(self, seq: np.ndarray) -> np.ndarray:
        """Circularly shift the sequence along the time axis."""
        max_s = self.cfg.time_shift_max
        shift = np.random.randint(-max_s, max_s + 1)
        return np.roll(seq, shift, axis=0) if shift != 0 else seq

    def temporal_warp(self, seq: np.ndarray, sigma: float = 0.2) -> np.ndarray:
        """
        Randomly stretch/compress local regions of the time axis via a
        smooth warp field generated from cumulative Gaussian noise.
        """
        T = seq.shape[0]
        warp = np.cumsum(np.random.normal(1.0, sigma, T))
        warp = warp / warp[-1] * (T - 1)
        indices = np.clip(np.round(warp).astype(int), 0, T - 1)
        return seq[indices]

    def random_dropout(self, seq: np.ndarray, drop_prob: float = 0.05) -> np.ndarray:
        """Randomly zero-out individual frames to simulate detection failures."""
        mask = np.random.binomial(1, 1 - drop_prob, size=seq.shape[0])
        return seq * mask[:, np.newaxis]

    def mirror_x(self, seq: np.ndarray) -> np.ndarray:
        """
        Flip x-coordinates to simulate left↔right hand variation.

        In dual-hand mode (``use_both_hands=True``) the left and right
        hand slots are also swapped so the hand identity remains consistent
        after flipping: what was the left hand becomes the right hand and
        vice versa.

        Feature layout (dual-hand with inter-hand):
            [0:63]   left  hand (21 pts × 3)
            [63:126] right hand (21 pts × 3)
            [126:]   inter-hand (6 dims, raw image-space)
        """
        mirrored = seq.copy()

        if self.cfg.use_both_hands:
            left_slice = slice(0, 63)
            right_slice = slice(63, 126)

            # Swap left ↔ right hand blocks
            left_copy = mirrored[:, left_slice].copy()
            mirrored[:, left_slice] = mirrored[:, right_slice]
            mirrored[:, right_slice] = left_copy

            # Flip x within each hand block (columns 0, 3, 6, … in each block)
            for start in (0, 63):
                mirrored[:, start::3] = 1.0 - mirrored[:, start::3]

            # Negate the x-component of inter-hand features (indices 126, 129)
            if self.cfg.use_inter_hand_features and seq.shape[1] > 126:
                mirrored[:, 126] = -mirrored[:, 126]   # relative wrist Δx
                mirrored[:, 129] = -mirrored[:, 129]   # relative index-tip Δx
        else:
            # Single-hand mode: flip x columns in the 63-feature vector
            mirrored[:, 0::3] = 1.0 - mirrored[:, 0::3]

        return mirrored

    # ──────────────────────────────────────────────────────────────────────
    # New augmentations
    # ──────────────────────────────────────────────────────────────────────

    def random_rotation_2d(
        self, seq: np.ndarray, max_angle_deg: float = 15.0
    ) -> np.ndarray:
        """
        Rotate the (x, y) plane of every landmark by a small random angle.

        Simulates wrist roll and slight camera tilt.  The z coordinate is
        left unchanged because it encodes depth, not planar orientation.
        Applies the same rotation angle to every frame so temporal coherence
        is preserved.
        """
        angle = np.random.uniform(-max_angle_deg, max_angle_deg)
        rad = np.deg2rad(angle)
        cos_a, sin_a = np.cos(rad), np.sin(rad)

        rotated = seq.copy()
        # x coords: columns 0, 3, 6, …   y coords: columns 1, 4, 7, …
        x_cols = np.arange(0, seq.shape[1], 3)
        y_cols = np.arange(1, seq.shape[1], 3)

        x = rotated[:, x_cols]
        y = rotated[:, y_cols]

        rotated[:, x_cols] = cos_a * x - sin_a * y
        rotated[:, y_cols] = sin_a * x + cos_a * y
        return rotated

    def speed_variation(
        self, seq: np.ndarray, speed_range: Tuple[float, float] = (0.8, 1.2)
    ) -> np.ndarray:
        """
        Resample the sequence at a randomly chosen speed factor.

        A factor < 1.0 compresses the gesture (fast signer); > 1.0 stretches
        it (slow signer).  The output is always padded/truncated to the
        original length to keep tensor shapes consistent.
        """
        T = seq.shape[0]
        factor = np.random.uniform(*speed_range)
        new_len = max(2, int(T / factor))

        # Sample `new_len` frames from the original sequence
        src_indices = np.linspace(0, T - 1, new_len)
        src_int = src_indices.astype(int)
        src_frac = src_indices - src_int

        # Linear interpolation between adjacent frames
        src_int_next = np.minimum(src_int + 1, T - 1)
        resampled = (
            seq[src_int] * (1 - src_frac[:, None])
            + seq[src_int_next] * src_frac[:, None]
        )

        if new_len >= T:
            return resampled[:T]

        # Pad short result with last-frame repetition
        pad = np.tile(resampled[-1:], (T - new_len, 1))
        return np.concatenate([resampled, pad], axis=0)

    def random_hand_scale(
        self, seq: np.ndarray, scale_range: Tuple[float, float] = (0.85, 1.15)
    ) -> np.ndarray:
        """
        Independently scale each hand block to simulate perspective variation
        (one hand closer to the camera than the other).

        Only meaningful in dual-hand mode; falls back to global scale otherwise.
        """
        if not self.cfg.use_both_hands:
            return self.random_scale(seq)

        result = seq.copy()
        for hand_slice in (slice(0, 63), slice(63, 126)):
            factor = np.random.uniform(*scale_range)
            result[:, hand_slice] *= factor
        return result

    # ──────────────────────────────────────────────────────────────────────
    # Composite augmentation
    # ──────────────────────────────────────────────────────────────────────

    def augment(self, seq: np.ndarray) -> np.ndarray:
        """
        Apply a random subset of augmentations.

        Each strategy fires independently with probability ``cfg.augmentation_prob``
        (default 0.5).  Rarer transforms (mirror, dropout) use a lower fraction
        to avoid over-applying semantics-altering ops.
        """
        p = self.cfg.augmentation_prob
        out = seq.copy()

        if np.random.random() < p:
            out = self.add_gaussian_noise(out)
        if np.random.random() < p:
            out = self.random_scale(out)
        if np.random.random() < p:
            out = self.temporal_shift(out)
        if np.random.random() < p:
            out = self.temporal_warp(out)
        if np.random.random() < p:
            out = self.random_rotation_2d(out)
        if np.random.random() < p:
            out = self.speed_variation(out)
        if np.random.random() < p * 0.6:
            out = self.random_hand_scale(out)
        if np.random.random() < p * 0.4:
            out = self.random_dropout(out)
        if np.random.random() < p * 0.3:
            out = self.mirror_x(out)

        return out


# ═══════════════════════════════════════════════════════════════════════════════
# Pipeline helper
# ═══════════════════════════════════════════════════════════════════════════════

def preprocess_pipeline(
    X_train: np.ndarray,
    y_train: np.ndarray,
    config: Optional[SignLingoConfig] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Apply data augmentation to the training set, appending augmented copies
    to the original arrays.

    Returns
    -------
    X_aug, y_aug : np.ndarray
        Augmented training data and labels.
    """
    cfg = config or get_config()
    if not cfg.use_augmentation:
        return X_train, y_train

    augmentor = DataAugmentor(cfg)
    X_aug, y_aug = list(X_train), list(y_train)

    for i in range(len(X_train)):
        if np.random.random() < cfg.augmentation_prob:
            X_aug.append(augmentor.augment(X_train[i]))
            y_aug.append(y_train[i])

    X_aug = np.array(X_aug)
    y_aug = np.array(y_aug)

    print(f"  Augmentation: {len(X_train)} → {len(X_aug)} samples")
    return X_aug, y_aug
