"""
SignLingo — Centralized Configuration

All hyperparameters, paths, and language-specific settings are managed here.
Supports multiple sign languages by switching the LANGUAGE preset.
"""

import os
from dataclasses import dataclass, field
from typing import Optional, List, Dict


# ═══════════════════════════════════════════════════════════════════════════════
# LANGUAGE PRESETS
# ═══════════════════════════════════════════════════════════════════════════════

LANGUAGE_PRESETS: Dict[str, dict] = {
    "ASL": {
        "name": "American Sign Language",
        "dataset_source": "WLASL (Word-Level American Sign Language)",
        "dataset_url": "https://dxli94.github.io/WLASL/",
        "num_landmarks": 63,           # 21 hand points × 3 coords (x, y, z)
        "max_hands": 2,
        "default_data_dir": "data/organized",
        "gloss_json": "wlasl-processed/WLASL_v0.3.json",
    },
    "ISL": {
        "name": "Indian Sign Language",
        "dataset_source": "INCLUDE / ISL-CSLTR / Custom ISL datasets",
        "dataset_url": "https://zenodo.org/record/4010759",
        "num_landmarks": 63,
        "max_hands": 2,
        "default_data_dir": "data/isl_organized",
        "gloss_json": None,            # ISL datasets typically use folder names
    },
}


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class SignLingoConfig:
    """
    Central configuration for the entire SignLingo pipeline.

    Attributes
    ----------
    language : str
        Active sign language preset key (e.g., "ASL", "ISL").
    model_arch : str
        Model architecture to use.  One of:
            "lstm_attention"  — Bidirectional LSTM + Attention  (default)
            "vit"             — Vision Transformer
            "resnet50"        — ResNet-50 (1-D temporal)
            "vgg16"           — VGG-16  (1-D temporal)
            "vgg19"           — VGG-19  (1-D temporal)
    """

    # ── Language ──────────────────────────────────────────────────────────
    language: str = "ASL"

    # ── Model selection ──────────────────────────────────────────────────
    model_arch: str = "vit"

    # ── Paths ────────────────────────────────────────────────────────────
    data_dir: str = "data/organized"
    output_dir: str = "models"
    results_dir: str = "results"
    logs_dir: str = "logs"
    landmarks_dir: str = "data/landmarks"

    # ── Landmark / feature dimensions ────────────────────────────────────
    num_hand_points: int = 21
    num_coords: int = 3
    max_hands: int = 2
    sequence_length: int = 30          # temporal frames per sample

    # ── Training hyperparameters ─────────────────────────────────────────
    epochs: int = 80
    batch_size: int = 16
    learning_rate: float = 0.0005
    weight_decay: float = 1e-4
    test_size: float = 0.20
    validation_split: float = 0.15
    random_seed: int = 42

    # ── Early stopping & scheduler ───────────────────────────────────────
    patience: int = 15
    min_delta: float = 0.0005
    lr_reduce_factor: float = 0.5
    lr_reduce_patience: int = 5
    min_lr: float = 1e-7

    # ── Data filters ─────────────────────────────────────────────────────
    min_videos_per_class: int = 9
    max_classes: Optional[int] = None  # None = use all valid classes

    # ── Augmentation ─────────────────────────────────────────────────────
    use_augmentation: bool = True
    augmentation_prob: float = 0.5
    noise_factor: float = 0.01
    scale_range: tuple = (0.95, 1.05)
    time_shift_max: int = 2

    # ── Dual-hand feature extraction ─────────────────────────────────────
    use_both_hands: bool = True          # extract left + right hand separately
    use_inter_hand_features: bool = True # append 6-dim relative-position vector

    # ── MediaPipe ────────────────────────────────────────────────────────
    mp_detection_confidence: float = 0.7
    mp_tracking_confidence: float = 0.7

    # ── ViT-specific hyperparameters ─────────────────────────────────────
    vit_embed_dim: int = 128
    vit_num_heads: int = 4
    vit_num_layers: int = 4
    vit_mlp_dim: int = 256
    vit_dropout: float = 0.1

    # ── LSTM-specific hyperparameters ────────────────────────────────────
    lstm_units: List[int] = field(default_factory=lambda: [256, 128, 64])
    lstm_dropout: float = 0.3
    lstm_recurrent_dropout: float = 0.3

    # ── Dense head ───────────────────────────────────────────────────────
    dense_units: List[int] = field(default_factory=lambda: [128, 64])
    dense_dropout: List[float] = field(default_factory=lambda: [0.4, 0.3])

    # ── Sentence formation ───────────────────────────────────────────────
    sentence_smoothing_window: int = 5
    sentence_confidence_threshold: float = 0.6
    sentence_max_gap_seconds: float = 2.0

    # ── Webcam / inference ───────────────────────────────────────────────
    webcam_resolution: tuple = (1280, 720)
    webcam_fps: int = 30
    inference_confidence_threshold: float = 0.6

    # ── Derived properties ───────────────────────────────────────────────

    @property
    def num_landmarks(self) -> int:
        """Total features per frame, accounting for dual-hand and inter-hand modes."""
        single = self.num_hand_points * self.num_coords   # 63
        if self.use_both_hands:
            total = single * 2                             # 126 (left + right)
            if self.use_inter_hand_features:
                total += 6                                 # +6 relative-position dims
            return total
        return single

    @property
    def input_shape(self) -> tuple:
        """Input tensor shape for models: (sequence_length, num_landmarks)."""
        return (self.sequence_length, self.num_landmarks)

    @property
    def language_preset(self) -> dict:
        """Return the active language preset dictionary."""
        return LANGUAGE_PRESETS.get(self.language, LANGUAGE_PRESETS["ASL"])

    # ── Helpers ──────────────────────────────────────────────────────────

    def ensure_dirs(self):
        """Create all output directories if they don't exist."""
        for d in [self.output_dir, self.results_dir, self.logs_dir]:
            os.makedirs(d, exist_ok=True)

    def summary(self) -> str:
        """Human-readable config summary."""
        lines = [
            "═" * 60,
            "  SignLingo Configuration",
            "═" * 60,
            f"  Language      : {self.language} ({self.language_preset['name']})",
            f"  Model         : {self.model_arch}",
            f"  Data dir      : {self.data_dir}",
            f"  Sequence len  : {self.sequence_length}",
            f"  Landmarks     : {self.num_landmarks}",
            f"  Epochs        : {self.epochs}",
            f"  Batch size    : {self.batch_size}",
            f"  Learning rate : {self.learning_rate}",
            f"  Augmentation  : {'ON' if self.use_augmentation else 'OFF'}",
            "═" * 60,
        ]
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE: module-level default config
# ═══════════════════════════════════════════════════════════════════════════════

_default_config = SignLingoConfig()


def get_config(**overrides) -> SignLingoConfig:
    """
    Factory to create a config, optionally overriding defaults.

    Examples
    --------
    >>> cfg = get_config(language="ISL", model_arch="vit", epochs=100)
    """
    return SignLingoConfig(**overrides)
