"""
signlingo.models.lstm_attention
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Bidirectional LSTM with a learned temporal Attention mechanism.

Architecture
------------
Input → LayerNorm → BiLSTM(256) → BN → BiLSTM(128) → BN → BiLSTM(64) → BN
  → Attention Pooling → Dense(128) → BN → Dropout → Dense(64) → BN → Dropout
  → Softmax(num_classes)

This model captures temporal dynamics of hand-landmark sequences through
bidirectional recurrence and uses attention to focus on the most
discriminative time steps in a sign gesture.
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
from typing import Optional

from signlingo.config import SignLingoConfig, get_config


# ═══════════════════════════════════════════════════════════════════════════════
# Attention layer
# ═══════════════════════════════════════════════════════════════════════════════

@keras.utils.register_keras_serializable(package="SignLingo")
class TemporalAttention(layers.Layer):
    """
    Learned scalar attention over the temporal axis.

    Given an input of shape (batch, T, D), computes attention weights α_t
    via a Dense(1) + softmax, then returns the weighted sum over T,
    yielding shape (batch, D).
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.score_dense = layers.Dense(1, activation="tanh")

    def call(self, x):
        # x: (B, T, D)
        scores = self.score_dense(x)              # (B, T, 1)
        scores = tf.squeeze(scores, axis=-1)       # (B, T)
        weights = tf.nn.softmax(scores, axis=-1)   # (B, T)
        weights = tf.expand_dims(weights, axis=-1) # (B, T, 1)
        context = tf.reduce_sum(x * weights, axis=1)  # (B, D)
        return context

    def get_config(self):
        return super().get_config()


# ═══════════════════════════════════════════════════════════════════════════════
# Model builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_lstm_attention_model(
    num_classes: int,
    config: Optional[SignLingoConfig] = None,
) -> keras.Model:
    """
    Build a Bidirectional LSTM model with temporal attention.

    Parameters
    ----------
    num_classes : int
        Number of sign language classes.
    config : SignLingoConfig, optional
        Hyperparameter source.

    Returns
    -------
    keras.Model
        Compiled-ready (but not yet compiled) Keras model.
    """
    cfg = config or get_config()
    input_shape = cfg.input_shape
    units = cfg.lstm_units            # e.g. [256, 128, 64]
    drop = cfg.lstm_dropout
    rec_drop = cfg.lstm_recurrent_dropout
    dense_units = cfg.dense_units     # e.g. [128, 64]
    dense_drops = cfg.dense_dropout   # e.g. [0.4, 0.3]

    inp = layers.Input(shape=input_shape, name="landmark_input")

    x = layers.LayerNormalization(name="input_norm")(inp)

    # Stacked Bidirectional LSTM layers
    for i, u in enumerate(units):
        x = layers.Bidirectional(
            layers.LSTM(
                u,
                return_sequences=True,
                dropout=drop,
                recurrent_dropout=rec_drop,
                name=f"lstm_{i}",
            ),
            name=f"bilstm_{i}",
        )(x)
        x = layers.BatchNormalization(name=f"bn_lstm_{i}")(x)

    # Temporal attention pooling
    x = TemporalAttention(name="attention")(x)

    # Dense classification head
    for i, (du, dd) in enumerate(zip(dense_units, dense_drops)):
        x = layers.Dense(du, activation="relu", name=f"dense_{i}")(x)
        x = layers.BatchNormalization(name=f"bn_dense_{i}")(x)
        x = layers.Dropout(dd, name=f"drop_dense_{i}")(x)

    out = layers.Dense(num_classes, activation="softmax", name="predictions")(x)

    model = models.Model(inp, out, name="BiLSTM_Attention")
    return model
