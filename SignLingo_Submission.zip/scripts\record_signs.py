#!/usr/bin/env python3
"""
Record your own ASL letters from the webcam.

For each letter, hold the sign and press SPACE. Move the hand a little
while it records. Press SPACE again to pause. N goes to the next letter.

Keys
----
    Space   start or pause recording for this letter
    N       next letter
    P       previous letter
    C       delete samples for this letter
    Q       save and quit
"""

from __future__ import annotations

import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.data.hands_runtime import HandTracker, draw_hands
from signlingo.models.alphabet_cnn import ASL_LETTERS
from signlingo.models.personal_alphabet import SAMPLES_PATH

TARGET = 80


def load_existing(path: str):
    if not os.path.isfile(path):
        return [], []
    data = np.load(path, allow_pickle=False)
    landmarks = [row for row in data["landmarks"]]
    labels = [str(x) for x in data["labels"].tolist()]
    return landmarks, labels


def save(path: str, landmarks, labels):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not landmarks:
        if os.path.isfile(path):
            os.remove(path)
        return
    np.savez_compressed(
        path,
        landmarks=np.stack(landmarks).astype(np.float32),
        labels=np.array(labels),
    )


def count_for(labels, letter: str) -> int:
    return sum(1 for item in labels if item == letter)


def main():
    landmarks, labels = load_existing(SAMPLES_PATH)
    print(f"Recording into {SAMPLES_PATH}")
    print(f"Already saved: {len(labels)} samples")
    tracker = HandTracker(mode="video", max_hands=1, min_detection_confidence=0.5)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open a webcam.")
        tracker.close()
        return 1
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    index = 0
    recording = False
    tick = 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.flip(frame, 1)
            letter = ASL_LETTERS[index]
            detection = tracker.detect(frame)
            draw_hands(frame, detection)
            have_hand = bool(detection.hands)

            if recording and have_hand and tick % 2 == 0:
                if count_for(labels, letter) < TARGET:
                    landmarks.append(detection.hands[0].landmarks.astype(np.float32))
                    labels.append(letter)
            tick += 1

            h, w = frame.shape[:2]
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (w, 150), (20, 22, 26), -1)
            cv2.addWeighted(overlay, 0.82, frame, 0.18, 0, frame)
            color = (80, 220, 120) if recording else (230, 230, 230)
            cv2.putText(frame, f"Show {letter}", (20, 70), cv2.FONT_HERSHEY_SIMPLEX, 2.0, color, 3, cv2.LINE_AA)
            saved = count_for(labels, letter)
            state = "RECORDING" if recording else "paused"
            cv2.putText(
                frame,
                f"{saved}/{TARGET}   {state}   letter {index + 1}/{len(ASL_LETTERS)}",
                (20, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (80, 220, 120) if have_hand else (60, 60, 220),
                2,
                cv2.LINE_AA,
            )
            cv2.rectangle(frame, (0, h - 40), (w, h), (20, 22, 26), -1)
            cv2.putText(
                frame,
                "SPACE record/pause   N next   P previous   C clear this letter   Q save+quit",
                (12, h - 14),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (245, 245, 245),
                1,
                cv2.LINE_AA,
            )
            if not have_hand:
                cv2.putText(frame, "No hand", (w - 160, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (60, 60, 220), 2)

            cv2.imshow("SignLingo record", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q")):
                break
            elif key == ord(" "):
                recording = not recording
            elif key in (ord("n"), ord("N")):
                recording = False
                index = min(index + 1, len(ASL_LETTERS) - 1)
            elif key in (ord("p"), ord("P")):
                recording = False
                index = max(index - 1, 0)
            elif key in (ord("c"), ord("C")):
                recording = False
                keep = [(lm, lab) for lm, lab in zip(landmarks, labels) if lab != letter]
                landmarks = [lm for lm, _lab in keep]
                labels = [lab for _lm, lab in keep]
    finally:
        save(SAMPLES_PATH, landmarks, labels)
        cap.release()
        cv2.destroyAllWindows()
        tracker.close()
        print(f"Saved {len(labels)} samples to {SAMPLES_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
