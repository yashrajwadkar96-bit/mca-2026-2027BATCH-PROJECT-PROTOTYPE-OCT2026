"""
Turn a stream of stable letter predictions into spelled text.

A letter is committed once, then the hand must leave that prediction
(confidence drops, or a different letter wins) before the same letter
can be added again. That is how double letters such as the two L's in
HELLO are typed.
"""

from __future__ import annotations


class SpellingBuffer:
    def __init__(self):
        self.text = ""
        self._armed = True
        self._current: str | None = None

    def observe(
        self,
        letter: str,
        confidence: float,
        stability: float,
        threshold: float = 0.55,
        stability_min: float = 0.75,
    ) -> str | None:
        """Return the letter if it was just committed, otherwise None."""
        if confidence < threshold or stability < stability_min:
            self._armed = True
            return None
        if letter != self._current:
            self._current = letter
            self._armed = True
        if not self._armed:
            return None
        self.text += letter
        self._armed = False
        return letter

    def space(self):
        if self.text and not self.text.endswith(" "):
            self.text += " "
        self._armed = True
        self._current = None

    def backspace(self):
        self.text = self.text[:-1]
        self._armed = True

    def clear(self):
        self.text = ""
        self._armed = True
        self._current = None

    def tokens(self) -> list[str]:
        return [t for t in self.text.strip().upper().split() if t]
