"""
Small CNN for static ASL fingerspelling (Sign Language MNIST).

Input: 28×28 grayscale hand crop
Output: 24 letter classes (A–Y except J). J and Z require motion and
are not in this dataset.
"""

from tensorflow import keras
from tensorflow.keras import layers, models


ASL_MNIST_LABELS = [i for i in range(25) if i != 9]  # skip J
ASL_LETTERS = [chr(ord("A") + i) for i in ASL_MNIST_LABELS]


def mnist_label_to_index(raw_label: int) -> int:
    """Map Sign-MNIST raw label (0–24, missing 9) to a dense 0–23 index."""
    if raw_label == 9:
        raise ValueError("Label 9 (J) is not present in Sign Language MNIST")
    return ASL_MNIST_LABELS.index(raw_label)


def index_to_letter(idx: int) -> str:
    return ASL_LETTERS[idx]


def build_alphabet_cnn(num_classes: int = 24) -> keras.Model:
    inputs = keras.Input(shape=(28, 28, 1), name="hand_crop")
    x = layers.Rescaling(1.0 / 255.0)(inputs)
    x = layers.Conv2D(32, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(128, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Flatten()(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.4)(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="letter")(x)
    return models.Model(inputs, outputs, name="asl_alphabet_cnn")
