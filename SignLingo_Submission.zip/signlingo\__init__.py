"""
SignLingo: Multi-Language Sign Language Recognition & Sentence Formation

A deep learning system for recognizing sign language gestures (ISL & ASL)
and forming grammatically coherent sentences from sequences of recognized signs.

Supports multiple model architectures:
    - Vision Transformer (ViT) — primary model
    - Bidirectional LSTM with Attention
    - ResNet-50 (adapted for temporal landmarks)
    - VGG16 / VGG19 (adapted for temporal landmarks)

Uses MediaPipe for real-time hand landmark extraction and scikit-learn
for dataset splitting and preprocessing.
"""

__version__ = "1.0.0"
__author__ = "Ishika"
__project__ = "SignLingo"
