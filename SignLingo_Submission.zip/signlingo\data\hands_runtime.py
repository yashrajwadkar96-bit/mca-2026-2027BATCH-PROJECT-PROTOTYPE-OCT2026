"""
MediaPipe Hands runtime compatible with MediaPipe 1.x Tasks.

The original SignLingo code used ``mp.solutions.hands``, which was removed
in MediaPipe 1.x.  This module downloads Google's official Hand Landmarker
and exposes a small, stable API for landmark extraction and drawing.
"""

from __future__ import annotations

import os
import time
import urllib.request
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import cv2
import numpy as np

HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17),
]

_DEFAULT_MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
)


def default_model_path() -> str:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, "models", "mp", "hand_landmarker.task")


def ensure_hand_landmarker(model_path: Optional[str] = None) -> str:
    """Download the MediaPipe hand landmarker if it is not already on disk."""
    path = model_path or default_model_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.isfile(path) and os.path.getsize(path) > 1_000_000:
        return path

    print(f"  Downloading MediaPipe hand landmarker to {path}")
    urllib.request.urlretrieve(_DEFAULT_MODEL_URL, path)
    return path


@dataclass
class DetectedHand:
    label: str
    score: float
    landmarks: np.ndarray  # (21, 3) normalized image coords


@dataclass
class HandDetection:
    hands: List[DetectedHand] = field(default_factory=list)

    @property
    def multi_hand_landmarks(self) -> List[DetectedHand]:
        return self.hands

    def labels(self) -> List[str]:
        return [f"{h.label[0]}({h.score:.0%})" for h in self.hands]


class HandTracker:
    """
    Thin wrapper around MediaPipe Tasks HandLandmarker.

    Parameters
    ----------
    mode : str
        ``"image"`` for photos / uploaded files, ``"video"`` for webcam.
    """

    def __init__(
        self,
        mode: str = "video",
        max_hands: int = 2,
        min_detection_confidence: float = 0.7,
        min_tracking_confidence: float = 0.7,
        model_path: Optional[str] = None,
    ):
        import mediapipe as mp
        from mediapipe.tasks.python.core import base_options as base_options_module
        from mediapipe.tasks.python.vision import (
            HandLandmarker,
            HandLandmarkerOptions,
            RunningMode,
        )

        self._mp = mp
        self.mode = mode
        self.max_hands = max_hands
        path = ensure_hand_landmarker(model_path)
        running = RunningMode.VIDEO if mode == "video" else RunningMode.IMAGE

        options = HandLandmarkerOptions(
            base_options=base_options_module.BaseOptions(model_asset_path=path),
            running_mode=running,
            num_hands=max_hands,
            min_hand_detection_confidence=min_detection_confidence,
            min_hand_presence_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        self._landmarker = HandLandmarker.create_from_options(options)
        self._timestamp_ms = 0
        self._last_time = time.time()

    def detect(self, frame_bgr: np.ndarray, timestamp_ms: Optional[int] = None) -> HandDetection:
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        rgb = np.ascontiguousarray(rgb)
        mp_image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)

        if self.mode == "video":
            if timestamp_ms is None:
                now = time.time()
                delta = max(1, int((now - self._last_time) * 1000))
                self._timestamp_ms += delta
                self._last_time = now
            else:
                self._timestamp_ms = max(self._timestamp_ms + 1, int(timestamp_ms))
            result = self._landmarker.detect_for_video(mp_image, self._timestamp_ms)
        else:
            result = self._landmarker.detect(mp_image)

        hands: List[DetectedHand] = []
        if not result.hand_landmarks:
            return HandDetection(hands)

        for i, lm_list in enumerate(result.hand_landmarks):
            coords = np.array([[lm.x, lm.y, lm.z] for lm in lm_list], dtype=np.float32)
            label = "Right"
            score = 1.0
            if result.handedness and i < len(result.handedness):
                cat = result.handedness[i][0]
                label = cat.category_name
                score = float(cat.score)
            hands.append(DetectedHand(label=label, score=score, landmarks=coords))
        return HandDetection(hands)

    def close(self):
        try:
            self._landmarker.close()
        except Exception:
            pass

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


def hand_bounding_box(
    hand: DetectedHand,
    frame_shape: Tuple[int, ...],
    padding: float = 0.35,
) -> Tuple[int, int, int, int]:
    """Return (x1, y1, x2, y2) pixel crop around a detected hand."""
    h, w = frame_shape[:2]
    xs = hand.landmarks[:, 0] * w
    ys = hand.landmarks[:, 1] * h
    x1, x2 = float(xs.min()), float(xs.max())
    y1, y2 = float(ys.min()), float(ys.max())
    bw, bh = max(x2 - x1, 1.0), max(y2 - y1, 1.0)
    pad_x, pad_y = bw * padding, bh * padding
    x1 = int(max(0, x1 - pad_x))
    y1 = int(max(0, y1 - pad_y))
    x2 = int(min(w, x2 + pad_x))
    y2 = int(min(h, y2 + pad_y))
    # Square crop for the alphabet CNN
    side = max(x2 - x1, y2 - y1)
    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
    x1 = max(0, cx - side // 2)
    y1 = max(0, cy - side // 2)
    x2 = min(w, x1 + side)
    y2 = min(h, y1 + side)
    return x1, y1, x2, y2


def crop_primary_hand(frame_bgr: np.ndarray, detection: HandDetection) -> Optional[np.ndarray]:
    if not detection.hands:
        return None
    # Prefer the larger / higher-confidence hand
    hand = max(detection.hands, key=lambda h: h.score)
    x1, y1, x2, y2 = hand_bounding_box(hand, frame_bgr.shape)
    if x2 <= x1 or y2 <= y1:
        return None
    return frame_bgr[y1:y2, x1:x2]


def draw_hands(frame_bgr: np.ndarray, detection: HandDetection) -> np.ndarray:
    """Draw landmarks and connections. Mutates and returns the frame."""
    h, w = frame_bgr.shape[:2]
    for hand in detection.hands:
        color = (50, 200, 255) if hand.label == "Left" else (50, 255, 180)
        conn = (30, 140, 255) if hand.label == "Left" else (30, 200, 130)
        pts = []
        for x, y, _z in hand.landmarks:
            px, py = int(x * w), int(y * h)
            pts.append((px, py))
            cv2.circle(frame_bgr, (px, py), 3, color, -1, cv2.LINE_AA)
        for a, b in HAND_CONNECTIONS:
            cv2.line(frame_bgr, pts[a], pts[b], conn, 2, cv2.LINE_AA)
        wx, wy = pts[0]
        cv2.putText(
            frame_bgr, hand.label, (wx - 20, max(20, wy - 18)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv2.LINE_AA,
        )
    return frame_bgr
