"""
Load the trained ASL fingerspelling CNN and turn a hand crop into a letter.

The network was trained on Sign Language MNIST: 28×28 grayscale images,
pixel values 0–255, 24 classes (A–Y, skipping J).
"""

from __future__ import annotations

import os
from typing import List, Tuple

import cv2
import numpy as np
from tensorflow import keras

from signlingo.models.alphabet_cnn import ASL_LETTERS, index_to_letter


def default_model_path() -> str:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, "models", "alphabet_cnn.keras")


def bgr_crop_to_input(bgr: np.ndarray) -> np.ndarray:
    """Resize a BGR hand crop to the CNN input, shape (28, 28, 1), values 0–255."""
    if bgr is None or bgr.size == 0:
        raise ValueError("Empty hand crop")
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    small = cv2.resize(gray, (28, 28), interpolation=cv2.INTER_AREA)
    return small.astype(np.float32)[..., None]


def pixels_to_input(pixels: np.ndarray) -> np.ndarray:
    """Flattened 784-vector or (28, 28) array → (28, 28, 1)."""
    arr = np.asarray(pixels, dtype=np.float32).reshape(28, 28)
    return arr[..., None]


class AlphabetPredictor:
    def __init__(self, model_path: str | None = None):
        path = model_path or default_model_path()
        if not os.path.isfile(path):
            raise FileNotFoundError(
                f"Alphabet model not found at {path}. "
                "Train it with: python scripts/train_alphabet.py"
            )
        self.model_path = path
        self.model = keras.models.load_model(path)
        self.letters = list(ASL_LETTERS)

    def predict_input(self, image: np.ndarray) -> Tuple[str, float, np.ndarray]:
        """``image`` is (28, 28, 1) with values in 0–255."""
        batch = np.asarray(image, dtype=np.float32)[None, ...]
        probs = self.model.predict(batch, verbose=0)[0]
        idx = int(np.argmax(probs))
        return index_to_letter(idx), float(probs[idx]), probs

    def predict_bgr_crop(self, bgr: np.ndarray) -> Tuple[str, float, np.ndarray]:
        return self.predict_input(bgr_crop_to_input(bgr))

    def top_k(self, probs: np.ndarray, k: int = 3) -> List[Tuple[str, float]]:
        order = np.argsort(probs)[::-1][:k]
        return [(self.letters[int(i)], float(probs[int(i)])) for i in order]
