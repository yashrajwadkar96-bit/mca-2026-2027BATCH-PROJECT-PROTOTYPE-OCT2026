"""
signlingo.models.vit
~~~~~~~~~~~~~~~~~~~~

Vision Transformer (ViT) adapted for temporal hand-landmark sequences.

Instead of image patches, each "token" is a single frame of hand landmarks.
Positional embeddings are added, then the sequence is processed by a stack of
standard Transformer encoder blocks.  A [CLS] token is prepended and its
final representation is used for classification.

Architecture
------------
Input (T, D) → Linear Projection (T, embed_dim) → + Positional Embedding
  → + [CLS] token → N × TransformerBlock(MultiHeadAttention + FFN)
  → [CLS] output → LayerNorm → Dense(mlp_dim) → Dropout → Dense(num_classes)

Reference:
    Dosovitskiy et al., "An Image is Worth 16×16 Words: Transformers for
    Image Recognition at Scale," ICLR 2021.
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
from typing import Optional

from signlingo.config import SignLingoConfig, get_config


# ═══════════════════════════════════════════════════════════════════════════════
# Building blocks
# ═══════════════════════════════════════════════════════════════════════════════

@keras.utils.register_keras_serializable(package="SignLingo")
class PatchEmbedding(layers.Layer):
    """
    Linearly project each frame (landmark vector) into the embedding space
    and add learned positional embeddings.

    Also prepends a learnable [CLS] token.
    """

    def __init__(self, seq_len: int, embed_dim: int, **kwargs):
        super().__init__(**kwargs)
        self.seq_len = seq_len
        self.embed_dim = embed_dim
        self.projection = layers.Dense(embed_dim)
        self.cls_token = self.add_weight(
            shape=(1, 1, embed_dim),
            initializer="random_normal",
            trainable=True,
            name="cls_token",
        )
        self.pos_embed = self.add_weight(
            shape=(1, seq_len + 1, embed_dim),  # +1 for CLS
            initializer="random_normal",
            trainable=True,
            name="pos_embed",
        )

    def call(self, x):
        batch = tf.shape(x)[0]
        # Project frames: (B, T, D) → (B, T, embed_dim)
        x = self.projection(x)
        # Prepend CLS token
        cls = tf.broadcast_to(self.cls_token, [batch, 1, self.embed_dim])
        x = tf.concat([cls, x], axis=1)  # (B, T+1, embed_dim)
        x = x + self.pos_embed
        return x

    def get_config(self):
        cfg = super().get_config()
        cfg.update({"seq_len": self.seq_len, "embed_dim": self.embed_dim})
        return cfg


@keras.utils.register_keras_serializable(package="SignLingo")
class TransformerBlock(layers.Layer):
    """
    Standard Transformer encoder block:
        LayerNorm → MultiHeadAttention → Residual → LayerNorm → FFN → Residual
    """

    def __init__(self, embed_dim: int, num_heads: int, mlp_dim: int,
                 dropout: float = 0.1, **kwargs):
        super().__init__(**kwargs)
        self.ln1 = layers.LayerNormalization(epsilon=1e-6)
        self.mha = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=embed_dim // num_heads, dropout=dropout,
        )
        self.ln2 = layers.LayerNormalization(epsilon=1e-6)
        self.ffn = keras.Sequential([
            layers.Dense(mlp_dim, activation="gelu"),
            layers.Dropout(dropout),
            layers.Dense(embed_dim),
            layers.Dropout(dropout),
        ])

    def call(self, x, training=None):
        # Self-attention with residual
        x_norm = self.ln1(x)
        attn = self.mha(x_norm, x_norm, training=training)
        x = x + attn
        # Feed-forward with residual
        x_norm = self.ln2(x)
        ffn_out = self.ffn(x_norm, training=training)
        x = x + ffn_out
        return x


# ═══════════════════════════════════════════════════════════════════════════════
# Model builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_vit_model(
    num_classes: int,
    config: Optional[SignLingoConfig] = None,
) -> keras.Model:
    """
    Build a Vision Transformer for landmark-sequence classification.

    Parameters
    ----------
    num_classes : int
        Number of sign language classes.
    config : SignLingoConfig, optional

    Returns
    -------
    keras.Model
    """
    cfg = config or get_config()

    seq_len = cfg.sequence_length
    feat_dim = cfg.num_landmarks
    embed_dim = cfg.vit_embed_dim
    num_heads = cfg.vit_num_heads
    num_layers = cfg.vit_num_layers
    mlp_dim = cfg.vit_mlp_dim
    dropout = cfg.vit_dropout

    inp = layers.Input(shape=(seq_len, feat_dim), name="landmark_input")

    # Patch (frame) embedding + positional encoding + CLS
    x = PatchEmbedding(seq_len, embed_dim, name="patch_embed")(inp)
    x = layers.Dropout(dropout, name="embed_drop")(x)

    # Transformer encoder stack
    for i in range(num_layers):
        x = TransformerBlock(
            embed_dim, num_heads, mlp_dim, dropout,
            name=f"transformer_block_{i}",
        )(x)

    # Classification head — use [CLS] token (index 0)
    cls_output = layers.Lambda(lambda t: t[:, 0], name="cls_extract")(x)
    cls_output = layers.LayerNormalization(epsilon=1e-6, name="cls_norm")(cls_output)

    # MLP head
    cls_output = layers.Dense(mlp_dim, activation="gelu", name="mlp_head_1")(cls_output)
    cls_output = layers.Dropout(dropout, name="mlp_drop")(cls_output)
    out = layers.Dense(num_classes, activation="softmax", name="predictions")(cls_output)

    model = models.Model(inp, out, name="ViT_SignLanguage")
    return model
