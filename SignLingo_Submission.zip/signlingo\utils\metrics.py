"""
signlingo.utils.metrics
~~~~~~~~~~~~~~~~~~~~~~~

Model evaluation utilities: compute accuracy, top-k accuracy,
per-class precision/recall/F1, and format results.
"""

import json
import numpy as np
from pathlib import Path
from typing import Optional, List, Dict
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    top_k_accuracy_score,
)

from tensorflow import keras


def evaluate_model(
    model: keras.Model,
    X_test: np.ndarray,
    y_test: np.ndarray,
    class_names: List[str],
    results_dir: Optional[str] = None,
    model_name: str = "model",
) -> Dict:
    """
    Full evaluation pipeline: predict → compute metrics → print report → save.

    Parameters
    ----------
    model : keras.Model
    X_test : np.ndarray   (N, T, D)
    y_test : np.ndarray   (N, num_classes)  — one-hot encoded
    class_names : list of str
    results_dir : str, optional
        If provided, save the evaluation results to JSON.
    model_name : str

    Returns
    -------
    dict
        Contains accuracy, top-3 accuracy, per-class report, and loss.
    """
    # Predictions
    y_pred_probs = model.predict(X_test, verbose=0)
    y_pred = np.argmax(y_pred_probs, axis=1)
    y_true = np.argmax(y_test, axis=1)

    metrics = compute_metrics(y_true, y_pred, y_pred_probs, class_names)

    # Loss
    eval_results = model.evaluate(X_test, y_test, verbose=0)
    if isinstance(eval_results, list):
        metrics["loss"] = float(eval_results[0])
    else:
        metrics["loss"] = float(eval_results)

    metrics["model_name"] = model_name
    metrics["params"] = int(model.count_params())

    # Print
    _print_report(metrics, class_names)

    # Save
    if results_dir:
        out_path = Path(results_dir) / f"{model_name}_evaluation.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        # Convert numpy types for JSON serialization
        serializable = _make_serializable(metrics)
        with open(out_path, "w") as f:
            json.dump(serializable, f, indent=2)
        print(f"  💾 Saved: {out_path}")

    return metrics


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_pred_probs: np.ndarray,
    class_names: List[str],
) -> Dict:
    """
    Compute accuracy, top-3 accuracy, and full classification report.
    """
    acc = accuracy_score(y_true, y_pred)

    # Top-3 accuracy
    num_classes = len(class_names)
    k = min(3, num_classes)
    try:
        top3 = top_k_accuracy_score(y_true, y_pred_probs, k=k, labels=range(num_classes))
    except Exception:
        top3 = 0.0

    report = classification_report(
        y_true, y_pred, target_names=class_names, digits=3, output_dict=True,
    )

    cm = confusion_matrix(y_true, y_pred)

    return {
        "accuracy": float(acc),
        "top3_accuracy": float(top3),
        "classification_report": report,
        "confusion_matrix": cm.tolist(),
    }


def _print_report(metrics: Dict, class_names: List[str]):
    """Pretty-print evaluation results."""
    print(f"\n{'═' * 60}")
    print(f"  📊  Evaluation Results — {metrics.get('model_name', 'model')}")
    print(f"{'═' * 60}")
    print(f"  Accuracy     : {metrics['accuracy'] * 100:.2f}%")
    print(f"  Top-3 Acc    : {metrics['top3_accuracy'] * 100:.2f}%")
    print(f"  Loss         : {metrics.get('loss', 'N/A'):.4f}" if isinstance(metrics.get('loss'), float) else "")
    print(f"  Parameters   : {metrics.get('params', 'N/A'):,}")
    print()
    print(classification_report(
        list(range(len(class_names))),
        list(range(len(class_names))),   # placeholder — already printed in report dict
        target_names=class_names,
        digits=3,
    ) if False else "")  # we already have the dict, just print key stats
    print(f"{'═' * 60}")


def _make_serializable(obj):
    """Recursively convert numpy types to Python natives for JSON."""
    if isinstance(obj, dict):
        return {k: _make_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_make_serializable(v) for v in obj]
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj
