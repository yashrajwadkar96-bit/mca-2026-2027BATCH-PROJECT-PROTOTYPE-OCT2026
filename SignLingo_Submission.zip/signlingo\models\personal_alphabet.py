"""
Features and inference for a fingerspelling model trained on your own hand.

The camera model is a small network on 21 MediaPipe landmarks. It only
knows the letters you recorded.
"""

from __future__ import annotations

import os
from typing import List, Tuple

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SAMPLES_PATH = os.path.join(ROOT, "data", "my_signs", "samples.npz")
MODEL_PATH = os.path.join(ROOT, "models", "my_signs.keras")
META_PATH = os.path.join(ROOT, "models", "my_signs_meta.npz")


def landmarks_to_features(landmarks: np.ndarray) -> np.ndarray:
    """Wrist-centered, scale-normalized 21x3 landmarks, flattened to 63 values."""
    pts = np.asarray(landmarks, dtype=np.float32).reshape(21, 3).copy()
    pts -= pts[0]
    scale = float(np.linalg.norm(pts.reshape(-1, 3)[1:], axis=1).max())
    if scale > 1e-6:
        pts /= scale
    return pts.reshape(-1)


def mirror_features(features: np.ndarray) -> np.ndarray:
    """Flip the hand left-right so one recorded hand covers both."""
    pts = np.asarray(features, dtype=np.float32).reshape(21, 3).copy()
    pts[:, 0] *= -1
    return pts.reshape(-1)


class PersonalPredictor:
    def __init__(self, model_path: str | None = None, meta_path: str | None = None):
        from tensorflow import keras

        self.model_path = model_path or MODEL_PATH
        self.meta_path = meta_path or META_PATH
        if not os.path.isfile(self.model_path) or not os.path.isfile(self.meta_path):
            raise FileNotFoundError(
                "No personal hand model yet. Record signs, then train:\n"
                "  .\\.venv\\Scripts\\python.exe scripts\\record_signs.py\n"
                "  .\\.venv\\Scripts\\python.exe scripts\\train_my_signs.py"
            )
        meta = np.load(self.meta_path, allow_pickle=False)
        self.labels: List[str] = [str(x) for x in meta["labels"].tolist()]
        self.mean = np.asarray(meta["mean"], dtype=np.float32)
        self.std = np.asarray(meta["std"], dtype=np.float32)
        self.std = np.where(self.std < 1e-6, 1.0, self.std)
        self.model = keras.models.load_model(self.model_path)

    def predict(self, landmarks: np.ndarray) -> Tuple[str, float, np.ndarray]:
        feat = landmarks_to_features(landmarks)
        normed = ((feat - self.mean) / self.std).astype(np.float32)[None, ...]
        probs = self.model.predict(normed, verbose=0)[0]
        idx = int(np.argmax(probs))
        return self.labels[idx], float(probs[idx]), probs

    def top_k(self, probs: np.ndarray, k: int = 3):
        order = np.argsort(probs)[::-1][:k]
        return [(self.labels[int(i)], float(probs[int(i)])) for i in order]


def personal_model_ready() -> bool:
    return os.path.isfile(MODEL_PATH) and os.path.isfile(META_PATH)
