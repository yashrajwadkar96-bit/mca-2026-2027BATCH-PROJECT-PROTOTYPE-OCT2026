"""
signlingo.sentence.formation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sentence Formation Module — converts a raw stream of recognized sign glosses
into grammatically coherent English sentences.

Sign languages (ASL, ISL) use different grammar than spoken English.
For example, ASL follows a Topic–Comment structure and drops articles/copulas:
    ASL gloss sequence:  ["I", "SCHOOL", "GO"]
    English sentence:    "I am going to school."

This module handles:
    1. **Temporal smoothing** — de-duplicate consecutive repeated predictions
    2. **Grammar mapping**   — rule-based reordering from sign grammar → English
    3. **Semantic validation** — validate word relationships and fix common errors
    4. **Punctuation & casing** — basic sentence polishing

The design is extensible: language-specific grammar rules are stored in
dictionaries that can be swapped out for ISL or other sign languages.
"""

import re
from collections import deque
from typing import List, Optional, Dict, Tuple

from signlingo.config import SignLingoConfig, get_config


# ═══════════════════════════════════════════════════════════════════════════════
# Grammar rule tables (English target)
# ═══════════════════════════════════════════════════════════════════════════════

# Mapping from sign glosses to part-of-speech categories
_POS_MAP: Dict[str, str] = {
    # Pronouns
    "I": "PRON", "ME": "PRON", "YOU": "PRON", "HE": "PRON",
    "SHE": "PRON", "WE": "PRON", "THEY": "PRON",
    # Verbs
    "GO": "VERB", "WALK": "VERB", "DRINK": "VERB", "LIKE": "VERB",
    "HELP": "VERB", "STUDY": "VERB", "FINISH": "VERB", "KISS": "VERB",
    "CAN": "MODAL",
    # Nouns
    "BOOK": "NOUN", "DOG": "NOUN", "FISH": "NOUN", "FAMILY": "NOUN",
    "MOTHER": "NOUN", "MAN": "NOUN", "WOMAN": "NOUN", "COUSIN": "NOUN",
    "COMPUTER": "NOUN", "CHAIR": "NOUN", "TABLE": "NOUN", "BED": "NOUN",
    "SHIRT": "NOUN", "HAT": "NOUN", "CANDY": "NOUN", "SCHOOL": "NOUN",
    "LANGUAGE": "NOUN", "CLOTHES": "NOUN",
    # Adjectives
    "HOT": "ADJ", "COOL": "ADJ", "FINE": "ADJ", "TALL": "ADJ",
    "THIN": "ADJ", "BLACK": "ADJ", "BLUE": "ADJ", "WHITE": "ADJ",
    "ORANGE": "ADJ", "DEAF": "ADJ", "MANY": "ADJ",
    # Adverbs / time
    "NOW": "ADV", "LATER": "ADV", "BEFORE": "ADV",
    # Determiners
    "ALL": "DET",
    # Questions
    "WHAT": "WH", "WHO": "WH",
    # Interjections / responses
    "YES": "INTJ", "NO": "INTJ",
    # Special/events
    "GRADUATE": "VERB", "BOWLING": "NOUN", "THANKSGIVING": "NOUN",
    "HEARING": "ADJ", "YEAR": "NOUN",
}

# Verb conjugation helpers (simple present/progressive)
_PROGRESSIVE: Dict[str, str] = {
    "GO": "going", "WALK": "walking", "DRINK": "drinking",
    "STUDY": "studying", "HELP": "helping", "LIKE": "liking",
    "KISS": "kissing", "FINISH": "finishing", "GRADUATE": "graduating",
}

_SIMPLE_PRESENT: Dict[str, str] = {
    "GO": "go", "WALK": "walk", "DRINK": "drink",
    "STUDY": "study", "HELP": "help", "LIKE": "like",
    "KISS": "kiss", "FINISH": "finish", "GRADUATE": "graduate",
}

# Articles to insert before nouns
_REQUIRES_ARTICLE = {"BOOK", "DOG", "FISH", "COMPUTER", "CHAIR",
                      "TABLE", "BED", "SHIRT", "HAT", "CANDY",
                      "SCHOOL", "MAN", "WOMAN"}

# Pronoun mapping to English lowercase
_PRON_MAP = {
    "I": "I", "ME": "me", "YOU": "you", "HE": "he",
    "SHE": "she", "WE": "we", "THEY": "they",
}


# ═══════════════════════════════════════════════════════════════════════════════
# Sentence formation engine
# ═══════════════════════════════════════════════════════════════════════════════

class SentenceFormer:
    """
    Converts a sequence of sign language glosses into grammatically
    coherent English sentences.

    Parameters
    ----------
    config : SignLingoConfig, optional
    """

    def __init__(self, config: Optional[SignLingoConfig] = None):
        self.cfg = config or get_config()
        self._buffer: deque = deque(maxlen=50)
        self._last_gloss: Optional[str] = None

    # ──────────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────────

    def feed(self, gloss: str, confidence: float = 1.0) -> Optional[str]:
        """
        Feed one recognized gloss into the buffer.

        Returns a formed sentence when the buffer contains a plausible
        sentence boundary, otherwise ``None``.

        Parameters
        ----------
        gloss : str
            Upper-case sign gloss (e.g., "DRINK").
        confidence : float
            Recognition confidence (0–1).
        """
        gloss = gloss.upper().strip()

        # Skip low-confidence or duplicate consecutive signs
        if confidence < self.cfg.sentence_confidence_threshold:
            return None
        if gloss == self._last_gloss:
            return None

        self._last_gloss = gloss
        self._buffer.append(gloss)
        return None   # caller should use form_sentence() explicitly

    def form_sentence(self, glosses: Optional[List[str]] = None) -> str:
        """
        Form a grammatical English sentence from a list of glosses.

        Parameters
        ----------
        glosses : list of str, optional
            Gloss sequence.  If ``None``, uses the internal buffer.

        Returns
        -------
        str
            Grammatically reordered, capitalized, and punctuated sentence.
        """
        if glosses is None:
            glosses = list(self._buffer)
            self._buffer.clear()

        if not glosses:
            return ""

        glosses = [g.upper().strip() for g in glosses]

        # Step 1: De-duplicate consecutive repeats
        glosses = self._deduplicate(glosses)

        # Step 2: Classify parts of speech
        tagged = [(g, _POS_MAP.get(g, "UNK")) for g in glosses]

        # Step 3: Reorder from sign language grammar → English SVO
        reordered = self._reorder(tagged)

        # Step 4: Inflect and add function words
        words = self._inflect(reordered)

        # Step 5: Polish (capitalize, punctuate)
        sentence = self._polish(words)

        return sentence

    def reset(self):
        """Clear the internal buffer."""
        self._buffer.clear()
        self._last_gloss = None

    # ──────────────────────────────────────────────────────────────────────
    # Step 1: De-duplication
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _deduplicate(glosses: List[str]) -> List[str]:
        """Remove consecutive duplicate glosses."""
        if not glosses:
            return []
        result = [glosses[0]]
        for g in glosses[1:]:
            if g != result[-1]:
                result.append(g)
        return result

    # ──────────────────────────────────────────────────────────────────────
    # Step 2-3: Reordering (sign language → SVO English)
    # ──────────────────────────────────────────────────────────────────────

    def _reorder(self, tagged: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        """
        Reorder tagged glosses into Subject–Verb–Object (English) order.

        Sign languages often use SOV or Topic-Comment order:
            ASL: "BOOK I LIKE"  → English: "I like the book."
            ISL: "SCHOOL GO I"  → English: "I go to school."

        This rule-based reorder handles common patterns.
        """
        # Check for WH-question (what, who) — should stay at front
        wh_words = [(g, p) for g, p in tagged if p == "WH"]
        if wh_words:
            return self._reorder_question(tagged)

        subjects = []
        verbs = []
        objects_ = []
        modifiers = []   # ADJ, ADV, DET
        modals = []
        interjections = []
        rest = []

        for g, pos in tagged:
            if pos == "PRON":
                subjects.append((g, pos))
            elif pos == "VERB":
                verbs.append((g, pos))
            elif pos == "MODAL":
                modals.append((g, pos))
            elif pos == "NOUN":
                objects_.append((g, pos))
            elif pos in ("ADJ", "DET"):
                modifiers.append((g, pos))
            elif pos == "ADV":
                modifiers.append((g, pos))
            elif pos == "INTJ":
                interjections.append((g, pos))
            else:
                rest.append((g, pos))

        # If no explicit subject but there are verbs, imply "I"
        # (common in sign language: signer is implicit subject)
        # We only do this if the sentence is clearly a statement
        if not subjects and verbs and not interjections and not wh_words:
            pass  # Don't add implicit subject — keep it clean

        # Build SVO order
        ordered = interjections + subjects + modals + modifiers + verbs + objects_ + rest
        return ordered

    def _reorder_question(self, tagged: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        """Handle WH-questions: move WH word to front, verb second."""
        wh = [(g, p) for g, p in tagged if p == "WH"]
        others = [(g, p) for g, p in tagged if p != "WH"]

        subjects = [(g, p) for g, p in others if p == "PRON"]
        verbs = [(g, p) for g, p in others if p in ("VERB", "MODAL")]
        rest_ = [(g, p) for g, p in others if p not in ("PRON", "VERB", "MODAL")]

        return wh + verbs + subjects + rest_

    # ──────────────────────────────────────────────────────────────────────
    # Step 4: Inflection and function-word insertion
    # ──────────────────────────────────────────────────────────────────────

    def _inflect(self, tagged: List[Tuple[str, str]]) -> List[str]:
        """
        Convert tagged glosses into properly inflected English words.

        - Pronouns → lowercase mapping
        - Verbs → progressive or simple present
        - Nouns → add article if needed
        - Adjectives / adverbs → lowercase
        """
        words = []
        has_subject = any(p == "PRON" for _, p in tagged)

        for i, (gloss, pos) in enumerate(tagged):
            if pos == "PRON":
                words.append(_PRON_MAP.get(gloss, gloss.lower()))

            elif pos == "VERB":
                # Use progressive if there's a subject pronoun
                if has_subject:
                    # Add auxiliary
                    subj = next((g for g, p in tagged if p == "PRON"), "I")
                    if subj in ("I",):
                        aux = "am"
                    elif subj in ("HE", "SHE"):
                        aux = "is"
                    else:
                        aux = "are"
                    prog = _PROGRESSIVE.get(gloss, gloss.lower() + "ing")
                    # Only add auxiliary once (before the first verb)
                    if not any(w in ("am", "is", "are") for w in words):
                        words.append(aux)
                    words.append(prog)
                else:
                    words.append(_SIMPLE_PRESENT.get(gloss, gloss.lower()))

            elif pos == "MODAL":
                words.append(gloss.lower())

            elif pos == "NOUN":
                if gloss in _REQUIRES_ARTICLE:
                    # Check if preceded by an adjective (article goes before adj)
                    if words and words[-1] not in ("a", "an", "the"):
                        words.append("the")
                words.append(gloss.lower())

            elif pos in ("ADJ", "ADV"):
                words.append(gloss.lower())

            elif pos == "DET":
                words.append(gloss.lower())

            elif pos == "WH":
                words.append(gloss.lower())

            elif pos == "INTJ":
                words.append(gloss.lower())

            else:
                words.append(gloss.lower())

        return words

    # ──────────────────────────────────────────────────────────────────────
    # Step 5: Polish
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _polish(words: List[str]) -> str:
        """Capitalize first word, join, add punctuation."""
        if not words:
            return ""

        # Check if it's a question
        is_question = words[0] in ("what", "who", "where", "when", "how", "why")

        sentence = " ".join(words)

        # Fix double spaces
        sentence = re.sub(r"\s+", " ", sentence).strip()

        # Capitalize first letter
        sentence = sentence[0].upper() + sentence[1:]

        # Ensure "I" is always capitalized
        sentence = re.sub(r"\bi\b", "I", sentence)

        # Add punctuation
        if not sentence.endswith((".", "!", "?")):
            sentence += "?" if is_question else "."

        return sentence


# ═══════════════════════════════════════════════════════════════════════════════
# Convenience function
# ═══════════════════════════════════════════════════════════════════════════════

def glosses_to_sentence(glosses: List[str]) -> str:
    """
    One-shot conversion from glosses to English sentence.

    Examples
    --------
    >>> glosses_to_sentence(["I", "GO", "SCHOOL"])
    'I am going to the school.'
    >>> glosses_to_sentence(["WHAT", "YOU", "LIKE"])
    'What like you?'
    """
    return SentenceFormer().form_sentence(glosses)
