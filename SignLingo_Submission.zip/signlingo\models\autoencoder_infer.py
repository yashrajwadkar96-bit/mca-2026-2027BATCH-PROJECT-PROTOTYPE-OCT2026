"""
Load the trained sign autoencoder and reconstruct a 28×28 hand crop.

Pixel values may be 0–255 or already scaled to ``[0, 1]``. Reconstructions
and latent codes are always returned in the model's native range: images in
``[0, 1]``, latent codes as a 1-D float vector.
"""

from __future__ import annotations

import os

import numpy as np
from tensorflow import keras

from signlingo.models.sign_autoencoder import (
    LATENT_DIM,
    corrupt_signs,
    reconstruction_mse,
    scale_pixels,
)


def default_model_path() -> str:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, "models", "sign_autoencoder.keras")


class SignAutoencoder:
    def __init__(self, model_path: str | None = None):
        path = model_path or default_model_path()
        if not os.path.isfile(path):
            raise FileNotFoundError(
                f"Sign autoencoder not found at {path}. "
                "Train it with: python scripts/train_autoencoder.py"
            )
        self.model_path = path
        self.model = keras.models.load_model(path)
        self.encoder = keras.Model(
            self.model.input,
            self.model.get_layer("sign_encoder").output,
            name="sign_encoder",
        )
        self.decoder = self.model.get_layer("sign_decoder")
        self.latent_dim = int(self.encoder.output_shape[-1] or LATENT_DIM)

    def encode(self, images: np.ndarray) -> np.ndarray:
        batch = scale_pixels(images)
        if batch.ndim == 3:
            batch = batch[None, ...]
        return self.encoder.predict(batch, verbose=0)

    def decode(self, codes: np.ndarray) -> np.ndarray:
        latent = np.asarray(codes, dtype=np.float32)
        if latent.ndim == 1:
            latent = latent[None, ...]
        return self.decoder.predict(latent, verbose=0)

    def reconstruct(self, images: np.ndarray) -> np.ndarray:
        batch = scale_pixels(images)
        single = batch.shape[0] == 1 and np.asarray(images).ndim <= 3
        if batch.ndim == 3:
            batch = batch[None, ...]
        rebuilt = self.model.predict(batch, verbose=0)
        return rebuilt[0] if single else rebuilt

    def denoise(
        self,
        images: np.ndarray,
        noise_std: float,
        rng: np.random.Generator | None = None,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, float]:
        """
        Corrupt ``images``, reconstruct them, and report both errors.

        Returns clean, noisy, reconstructed, noisy MSE, and reconstructed MSE.
        Images are a single crop or a batch in 0–255 or ``[0, 1]``.
        """
        clean = scale_pixels(images)
        if clean.ndim == 3:
            clean = clean[None, ...]
        noisy = corrupt_signs(clean, noise_std=noise_std, rng=rng)
        rebuilt = self.model.predict(noisy, verbose=0)
        return (
            clean,
            noisy,
            rebuilt,
            reconstruction_mse(clean, noisy),
            reconstruction_mse(clean, rebuilt),
        )
