#!/usr/bin/env python3
"""
Train a fingerspelling network from data/my_signs/samples.npz.

Letters with fewer than 20 saved frames are skipped. Each saved hand is
also mirrored, so the model can see a left or a right hand.

Usage
-----
    python scripts/train_my_signs.py
"""

from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.models.personal_alphabet import (
    META_PATH,
    MODEL_PATH,
    SAMPLES_PATH,
    landmarks_to_features,
    mirror_features,
)

MIN_PER_LETTER = 20
METRICS_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "results", "my_signs_metrics.json"))


def main(samples_path: str = SAMPLES_PATH, model_path: str = MODEL_PATH, meta_path: str = META_PATH, metrics_path: str = METRICS_PATH):
    if not os.path.isfile(samples_path):
        print(f"No recordings at {samples_path}")
        print("Record first:  .\\.venv\\Scripts\\python.exe scripts\\record_signs.py")
        return 1

    data = np.load(samples_path, allow_pickle=False)
    raw = data["landmarks"]
    letters = np.array([str(x) for x in data["labels"].tolist()])
    counts = {letter: int(np.sum(letters == letter)) for letter in sorted(set(letters))}
    print("Samples per letter:")
    for letter, count in counts.items():
        mark = "ok" if count >= MIN_PER_LETTER else f"skipped (need {MIN_PER_LETTER})"
        print(f"  {letter}: {count}  {mark}")

    keep = np.array([counts[letter] >= MIN_PER_LETTER for letter in letters])
    raw = raw[keep]
    letters = letters[keep]
    labels = sorted(set(letters.tolist()))
    if len(labels) < 2:
        print("Need at least two letters with 20 or more samples each.")
        return 1

    features = []
    targets = []
    label_to_index = {letter: i for i, letter in enumerate(labels)}
    for lm, letter in zip(raw, letters):
        feat = landmarks_to_features(lm)
        features.append(feat)
        targets.append(label_to_index[letter])
        features.append(mirror_features(feat))
        targets.append(label_to_index[letter])
    x = np.stack(features).astype(np.float32)
    y = np.array(targets, dtype=np.int32)

    from sklearn.model_selection import train_test_split
    from tensorflow import keras

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42, stratify=y
    )
    mean = x_train.mean(axis=0)
    std = x_train.std(axis=0)
    std = np.where(std < 1e-6, 1.0, std)
    x_train = (x_train - mean) / std
    x_test = (x_test - mean) / std

    model = keras.Sequential(
        [
            keras.Input(shape=(63,)),
            keras.layers.Dense(128, activation="relu"),
            keras.layers.Dropout(0.3),
            keras.layers.Dense(64, activation="relu"),
            keras.layers.Dense(len(labels), activation="softmax"),
        ],
        name="my_signs",
    )
    model.compile(
        optimizer=keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    model.fit(
        x_train,
        y_train,
        validation_data=(x_test, y_test),
        epochs=40,
        batch_size=32,
        callbacks=[
            keras.callbacks.EarlyStopping(
                monitor="val_accuracy", patience=5, restore_best_weights=True
            )
        ],
        verbose=2,
    )
    probs = model.predict(x_test, verbose=0)
    pred = np.argmax(probs, axis=1)
    acc = float(np.mean(pred == y_test))
    print(f"Hold-out accuracy on your recordings: {acc:.3f}")
    print(f"Letters: {', '.join(labels)}")

    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    os.makedirs(os.path.dirname(metrics_path), exist_ok=True)
    model.save(model_path)
    np.savez(
        meta_path,
        labels=np.array(labels),
        mean=mean.astype(np.float32),
        std=std.astype(np.float32),
    )
    metrics = {
        "holdout_accuracy": round(acc, 4),
        "letters": labels,
        "train_rows": int(len(x_train)),
        "holdout_rows": int(len(x_test)),
        "note": "Hold-out is 20% of your recordings, including mirrored copies. This is not a webcam score on new signs you did not record.",
    }
    with open(metrics_path, "w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)
    print(f"Saved {model_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
