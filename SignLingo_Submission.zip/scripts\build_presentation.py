"""Build the college presentation for this SignLingo copy."""

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

NAVY = RGBColor(0x12, 0x1A, 0x24)
TEAL = RGBColor(0x1F, 0x8A, 0x70)
WHITE = RGBColor(0xF4, 0xF7, 0xF6)
MUTED = RGBColor(0xD5, 0xDE, 0xDA)
CARD = RGBColor(0x1C, 0x27, 0x33)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)


def blank():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = NAVY
    bar = slide.shapes.add_shape(1, Inches(0), Inches(0), Inches(0.18), Inches(7.5))
    bar.fill.solid()
    bar.fill.fore_color.rgb = TEAL
    bar.line.fill.background()
    return slide


def add_text(slide, text, x, y, w, h, size=24, bold=False, color=WHITE, align=PP_ALIGN.LEFT):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = box.text_frame
    frame.word_wrap = True
    p = frame.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = "Calibri"
    return frame


def bullets(slide, items, x, y, w, h, size=22):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = box.text_frame
    frame.word_wrap = True
    for i, item in enumerate(items):
        p = frame.paragraphs[0] if i == 0 else frame.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.level = 0
        p.space_after = Pt(10)
        run = p.add_run()
        run.text = item
        run.font.size = Pt(size)
        run.font.color.rgb = WHITE
        run.font.name = "Calibri"
    return frame


def title_slide():
    slide = blank()
    add_text(slide, "SIGNLINGO", 0.7, 1.8, 12, 1.1, 60, True)
    add_text(slide, "American Sign Language fingerspelling", 0.7, 3.1, 11, 0.6, 28, color=MUTED)
    add_text(
        slide,
        "A deep learning demo that reads a still hand photo,\npredicts a letter, and can turn known glosses into an English sentence.",
        0.7, 4.2, 10, 1.2, 22,
    )
    add_text(slide, "College project  ·  Python, TensorFlow, MediaPipe, Streamlit", 0.7, 6.4, 11, 0.4, 16, color=TEAL)


def section(heading, items, foot=None):
    slide = blank()
    add_text(slide, heading, 0.7, 0.4, 12, 0.7, 34, True)
    bullets(slide, items, 0.8, 1.4, 11.5, 5.2, 22)
    if foot:
        add_text(slide, foot, 0.7, 6.8, 12, 0.4, 14, color=TEAL)


title_slide()

section(
    "Aim",
    [
        "Recognize a static American Sign Language letter from a hand image.",
        "Show the predicted letter and a confidence score.",
        "Keep a history of saved predictions.",
        "Turn a short sequence of known sign glosses into an English sentence.",
        "Be honest about what this copy of the project can and cannot do.",
    ],
)

section(
    "What the downloaded repository already had",
    [
        "Source: github.com/ishgit/sign-language-project.",
        "A word-level pipeline: video, MediaPipe hand landmarks, then a neural network.",
        "Five architectures were written: ViT, BiLSTM with attention, ResNet-50, VGG-16, and VGG-19.",
        "A rule-based module turns glosses such as I, GO, and SCHOOL into English.",
        "The original README reports about 88% top-1 for a ViT on 50 WLASL classes.",
    ],
    "That 88% figure was already in the download. It was not measured again here.",
)

section(
    "What this folder did not include",
    [
        "No WLASL videos, so the word-level models could not be trained or tested.",
        "No file models/sign_language_model.h5, and no label encoder or scaler.",
        "MediaPipe 1.1 on this PC no longer has mp.solutions.hands.",
        "The old live webcam script depended on that removed API, so it could not start as shipped.",
        "A continuous live webcam demo was removed from the app because it was not reliable.",
    ],
)

section(
    "What we actually built",
    [
        "A Streamlit app: camera photo, image upload, letter, confidence, and top 3.",
        "Save prediction writes a history file. It does not train or update the model.",
        "A sentence page for known glosses, using the original grammar rules.",
        "A hold-out gallery that runs the trained CNN on images it did not train on.",
        "A MediaPipe Tasks hand landmarker, because the old Hands API is gone.",
    ],
)

section(
    "Dataset",
    [
        "Sign Language MNIST, training CSV from a public GitHub mirror of the Kaggle set.",
        "Each row is one label plus 784 grayscale pixels, a 28×28 image.",
        "27,455 images in the file. Split: 21,964 train and 5,491 hold-out.",
        "Split is stratified 80/20 with random seed 42.",
        "The official Kaggle test CSV was not in that mirror, so the hold-out is taken from the training file.",
    ],
)

section(
    "Letters the CNN can output",
    [
        "24 static letters: A through Y, skipping J.",
        "J and Z are not in Sign Language MNIST because those signs need motion.",
        "The network is a small CNN: three convolution blocks, then a dense layer and softmax.",
        "Input is 28×28×1. Pixel values are divided by 255 inside the model.",
        "Loss is sparse categorical cross-entropy. Optimizer is Adam. Batch size 128. Up to 8 epochs.",
    ],
)

section(
    "Measured results",
    [
        "These numbers are from scripts/train_alphabet.py on this machine.",
        "Hold-out accuracy: 99.95% on 5,491 images.",
        "Hold-out top-3 accuracy: 100%.",
        "Training ran 6 epochs. Last-epoch training accuracy was 99.76%.",
        "Last-epoch validation accuracy was 99.13%. Early stopping kept the best weights.",
    ],
    "This score is for clean 28×28 dataset images. It is not a webcam score.",
)

section(
    "Two different recognizers",
    [
        "Gallery: the CNN. It is accurate on Sign Language MNIST images.",
        "Camera photo and upload: 21 hand landmarks from MediaPipe, then hand-shape rules.",
        "A normal photo does not look like the MNIST images, so the CNN is not used on the camera.",
        "Landmark rules work better on a clear palm-facing photo, and worse on fist letters.",
        "A, S, T, M, and N are all closed fists, so they are easy to confuse.",
    ],
)

section(
    "Sentence formation",
    [
        "This part is rules, not a second neural network.",
        "Example: the glosses I GO become “I am going.”",
        "It only runs when every word is in a small gloss list, such as GO, SCHOOL, BOOK.",
        "Unknown words are left as typed text.",
        "It does not watch a video and it does not translate arbitrary English.",
    ],
)

section(
    "How to run it",
    [
        "Open PowerShell in the project folder.",
        "Run .\\run_app.bat",
        "Open http://localhost:8510",
        "Use Camera photo or Upload. The live webcam window is not part of the app.",
        "Python 3.14, TensorFlow 2.22, and MediaPipe 1.1 were used on this Windows PC. Training is CPU.",
    ],
)

section(
    "Limits to say in the viva",
    [
        "This demo recognizes static letters, not full WLASL words.",
        "J and Z are out of scope.",
        "The 99.95% score is the dataset hold-out, not a live camera test.",
        "Saving a prediction does not train the model.",
        "The original 88% word-level number was not reproduced, because the videos and weights are missing.",
    ],
)

out = r"C:\Users\yashr\OneDrive\Desktop\sign-language-project-main\sign-language-project-main\SignLingo_Presentation.pptx"
prs.save(out)
print(out)
