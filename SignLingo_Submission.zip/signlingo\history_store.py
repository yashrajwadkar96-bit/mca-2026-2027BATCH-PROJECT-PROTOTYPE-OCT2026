"""Persistent prediction history for the desktop application."""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any, Dict, List


def default_history_path() -> str:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    path = os.path.join(root, "data", "prediction_history.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


class PredictionHistory:
    def __init__(self, path: str | None = None):
        self.path = path or default_history_path()
        self.records: List[Dict[str, Any]] = []
        self._load()

    def _load(self):
        if os.path.isfile(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    self.records = json.load(f)
            except (json.JSONDecodeError, OSError):
                self.records = []

    def add(self, label: str, confidence: float, source: str, extras: Dict[str, Any] | None = None):
        rec = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "label": label,
            "confidence": round(float(confidence), 4),
            "source": source,
        }
        if extras:
            rec.update(extras)
        self.records.append(rec)
        self._save()

    def clear(self):
        self.records = []
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.records[-500:], f, indent=2)
