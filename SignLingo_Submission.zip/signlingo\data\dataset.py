"""
signlingo.data.dataset
~~~~~~~~~~~~~~~~~~~~~~

Dataset loading, class discovery, and train/test splitting for sign language
video datasets.  Works with any folder-structured dataset regardless of
sign language (ASL, ISL, etc.).

Expected folder layout::

    data_dir/
        class_a/
            video_001.mp4
            video_002.mp4
        class_b/
            ...
"""

import pickle
import numpy as np
from pathlib import Path
from collections import Counter
from typing import Tuple, List, Optional

from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras.utils import to_categorical

from signlingo.config import SignLingoConfig, get_config
from signlingo.data.landmark_extractor import LandmarkExtractor


class SignLanguageDataset:
    """
    End-to-end dataset handler: discover classes → extract landmarks →
    normalize → split → save artifacts.

    Parameters
    ----------
    config : SignLingoConfig, optional
        Pipeline configuration.
    """

    def __init__(self, config: Optional[SignLingoConfig] = None):
        self.cfg = config or get_config()
        self.extractor = LandmarkExtractor(self.cfg)

        # Populated after load()
        self.sign_classes: List[str] = []
        self.label_encoder: Optional[LabelEncoder] = None
        self.scaler: Optional[StandardScaler] = None

        self.X_train: Optional[np.ndarray] = None
        self.X_test: Optional[np.ndarray] = None
        self.y_train: Optional[np.ndarray] = None
        self.y_test: Optional[np.ndarray] = None

    # ──────────────────────────────────────────────────────────────────────
    # Main pipeline
    # ──────────────────────────────────────────────────────────────────────

    def load(self, data_dir: Optional[str] = None) -> "SignLanguageDataset":
        """
        Full pipeline: discover → extract → normalize → split.

        Returns *self* for chaining.
        """
        data_dir = data_dir or self.cfg.data_dir
        data_path = Path(data_dir)

        if not data_path.exists():
            raise FileNotFoundError(f"Data directory not found: {data_dir}")

        # 1. Discover valid classes
        valid_classes = self._discover_classes(data_path)
        self.sign_classes = [c.name for c in valid_classes]

        # 2. Extract landmarks from all videos
        X_raw, y_raw = self._extract_all(valid_classes)

        # 3. Normalize features
        X_norm = self._normalize(X_raw)

        # 4. Encode labels
        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(y_raw)
        y_cat = to_categorical(y_encoded)

        # 5. Train / test split
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_norm, y_cat,
            test_size=self.cfg.test_size,
            random_state=self.cfg.random_seed,
            stratify=y_encoded,
        )

        self._print_summary(y_raw)
        return self

    # ──────────────────────────────────────────────────────────────────────
    # Persistence
    # ──────────────────────────────────────────────────────────────────────

    def save_artifacts(self, output_dir: Optional[str] = None):
        """Save label encoder, scaler, and class list for inference."""
        out = Path(output_dir or self.cfg.output_dir)
        out.mkdir(parents=True, exist_ok=True)

        with open(out / "label_encoder.pkl", "wb") as f:
            pickle.dump(self.label_encoder, f)
        with open(out / "sign_classes.pkl", "wb") as f:
            pickle.dump(self.sign_classes, f)
        if self.scaler is not None:
            with open(out / "feature_scaler.pkl", "wb") as f:
                pickle.dump(self.scaler, f)

        print(f"  ✅ Artifacts saved to {out}/")

    # ──────────────────────────────────────────────────────────────────────
    # Internals
    # ──────────────────────────────────────────────────────────────────────

    def _discover_classes(self, data_path: Path) -> list:
        """Find class folders that meet the minimum video count threshold."""
        class_folders = sorted(
            [d for d in data_path.iterdir() if d.is_dir() and not d.name.startswith(".")]
        )
        if not class_folders:
            raise ValueError(f"No class folders found in {data_path}")

        valid = []
        for folder in class_folders:
            vids = self._list_videos(folder)
            if len(vids) >= self.cfg.min_videos_per_class:
                valid.append(folder)

        if self.cfg.max_classes is not None:
            valid = valid[: self.cfg.max_classes]

        print(f"📂  Found {len(class_folders)} total classes, "
              f"{len(valid)} meet threshold (≥ {self.cfg.min_videos_per_class} videos)")
        return valid

    def _extract_all(
        self, class_folders: list
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Extract landmarks for every video across all classes."""
        X, y = [], []

        for folder in class_folders:
            class_name = folder.name
            videos = self._list_videos(folder)
            print(f"  📹 {class_name}: {len(videos)} videos")

            for vf in tqdm(videos, desc=f"    {class_name}", leave=False):
                try:
                    lm = self.extractor.extract_from_video(vf)
                    if np.sum(np.abs(lm)) > 0:       # skip if no hand ever detected
                        X.append(lm)
                        y.append(class_name)
                except Exception:
                    pass                              # skip corrupt videos silently

        print(f"\n✅  Extracted {len(X)} samples across {len(set(y))} classes")
        return np.array(X), np.array(y)

    def _normalize(self, X: np.ndarray) -> np.ndarray:
        """Per-feature StandardScaler normalization."""
        original_shape = X.shape
        X_flat = X.reshape(-1, self.cfg.num_landmarks)
        self.scaler = StandardScaler()
        X_norm = self.scaler.fit_transform(X_flat)
        return X_norm.reshape(original_shape)

    @staticmethod
    def _list_videos(folder: Path) -> list:
        """Glob for common video extensions inside *folder*."""
        exts = ("*.mp4", "*.avi", "*.mov", "*.mkv")
        vids = []
        for ext in exts:
            vids.extend(folder.glob(ext))
        return sorted(vids)

    def _print_summary(self, y_raw: np.ndarray):
        """Pretty-print class distribution and split sizes."""
        counts = Counter(y_raw)
        print("\n📊  Class distribution:")
        for cls, n in sorted(counts.items()):
            bar = "█" * (n // 2)
            print(f"    {cls:20s} {bar} ({n})")
        print(f"\n  Train: {len(self.X_train)}  |  Test: {len(self.X_test)}")
