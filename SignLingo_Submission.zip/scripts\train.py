#!/usr/bin/env python3
"""
scripts/train.py — Unified training script for SignLingo.

Usage
-----
    # Train with default config (ViT, ASL)
    python scripts/train.py

    # Train a specific architecture
    python scripts/train.py --arch vit
    python scripts/train.py --arch lstm_attention
    python scripts/train.py --arch resnet50
    python scripts/train.py --arch vgg16

    # Train for ISL (provide your own ISL dataset)
    python scripts/train.py --language ISL --data-dir data/isl_organized

    # Custom hyperparameters
    python scripts/train.py --arch vit --epochs 100 --lr 0.001 --batch-size 32
"""

import os
import sys
import json
import pickle
import argparse
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.callbacks import (
    EarlyStopping,
    ModelCheckpoint,
    ReduceLROnPlateau,
    TensorBoard,
)

# Ensure project root is on the path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.config import get_config
from signlingo.data.dataset import SignLanguageDataset
from signlingo.data.preprocessing import preprocess_pipeline
from signlingo.models import build_model
from signlingo.utils.visualization import plot_training_history, plot_confusion_matrix
from signlingo.utils.metrics import evaluate_model


def parse_args():
    p = argparse.ArgumentParser(description="SignLingo — Model Training")
    p.add_argument("--arch", default="vit",
                   choices=["vit", "lstm_attention", "resnet50", "vgg16", "vgg19"],
                   help="Model architecture to train (default: vit)")
    p.add_argument("--language", default="ASL", choices=["ASL", "ISL"],
                   help="Sign language dataset (default: ASL)")
    p.add_argument("--data-dir", default=None,
                   help="Override dataset directory path")
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=0.0005)
    p.add_argument("--sequence-length", type=int, default=30)
    p.add_argument("--no-augment", action="store_true",
                   help="Disable data augmentation")
    p.add_argument("--output-dir", default="models")
    p.add_argument("--results-dir", default="results")
    return p.parse_args()


def main():
    args = parse_args()

    # ── Build config from CLI args ────────────────────────────────────────
    cfg = get_config(
        language=args.language,
        model_arch=args.arch,
        data_dir=args.data_dir or ("data/organized" if args.language == "ASL"
                                    else "data/isl_organized"),
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        sequence_length=args.sequence_length,
        use_augmentation=not args.no_augment,
        output_dir=args.output_dir,
        results_dir=args.results_dir,
    )
    cfg.ensure_dirs()
    print(cfg.summary())

    # ── System info ───────────────────────────────────────────────────────
    print(f"\n📊  TensorFlow {tf.__version__}")
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        print(f"  🎮  GPU detected: {len(gpus)} device(s)")
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
    else:
        print("  ⚠️   CPU only")

    # ── Load & prepare data ───────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print("  STEP 1 — Loading Dataset")
    print(f"{'═' * 60}")

    dataset = SignLanguageDataset(cfg)
    dataset.load()
    dataset.save_artifacts()

    num_classes = len(dataset.sign_classes)
    print(f"\n  Classes: {num_classes}")
    print(f"  Signs  : {', '.join(dataset.sign_classes)}")

    # ── Augment training data ─────────────────────────────────────────────
    X_train, y_train = preprocess_pipeline(
        dataset.X_train, dataset.y_train, config=cfg,
    )
    X_test, y_test = dataset.X_test, dataset.y_test

    # ── Build model ───────────────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  STEP 2 — Building {args.arch.upper()} Model")
    print(f"{'═' * 60}")

    model = build_model(num_classes, arch=args.arch, config=cfg)
    model.summary(print_fn=lambda x: print(f"  {x}"))

    optimizer = keras.optimizers.Adam(
        learning_rate=cfg.learning_rate,
    )
    model.compile(
        optimizer=optimizer,
        loss="categorical_crossentropy",
        metrics=["accuracy", keras.metrics.TopKCategoricalAccuracy(
            k=min(3, num_classes), name="top_3_accuracy")],
    )

    # ── Callbacks ─────────────────────────────────────────────────────────
    model_save_path = os.path.join(cfg.output_dir, f"best_{args.arch}.keras")
    callbacks = [
        EarlyStopping(
            monitor="val_loss", patience=cfg.patience,
            restore_best_weights=True, verbose=1,
        ),
        ModelCheckpoint(
            model_save_path, monitor="val_accuracy",
            save_best_only=True, mode="max", verbose=1,
        ),
        ReduceLROnPlateau(
            monitor="val_loss", factor=cfg.lr_reduce_factor,
            patience=cfg.lr_reduce_patience, min_lr=cfg.min_lr, verbose=1,
        ),
        TensorBoard(log_dir=os.path.join(cfg.logs_dir, args.arch)),
    ]

    # ── Train ─────────────────────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  STEP 3 — Training ({args.arch})")
    print(f"{'═' * 60}")
    print(f"  Epochs     : {cfg.epochs}")
    print(f"  Batch size : {cfg.batch_size}")
    print(f"  LR         : {cfg.learning_rate}")
    print()

    history = model.fit(
        X_train, y_train,
        validation_split=cfg.validation_split,
        epochs=cfg.epochs,
        batch_size=cfg.batch_size,
        callbacks=callbacks,
        verbose=1,
    )

    # ── Evaluate ──────────────────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  STEP 4 — Evaluation")
    print(f"{'═' * 60}")

    # Note: EarlyStopping(restore_best_weights=True) already restored
    # the best weights into `model`, so no need to reload from disk.
    metrics = evaluate_model(
        model, X_test, y_test,
        class_names=dataset.sign_classes,
        results_dir=cfg.results_dir,
        model_name=args.arch,
    )

    # ── Visualizations ────────────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  STEP 5 — Saving Visualizations")
    print(f"{'═' * 60}")

    plot_training_history(
        history,
        save_path=os.path.join(cfg.results_dir, f"{args.arch}_training_history.png"),
    )

    y_pred = np.argmax(model.predict(X_test, verbose=0), axis=1)
    y_true = np.argmax(y_test, axis=1)
    plot_confusion_matrix(
        y_true, y_pred,
        class_names=dataset.sign_classes,
        save_path=os.path.join(cfg.results_dir, f"{args.arch}_confusion_matrix.png"),
        title=f"Confusion Matrix — {args.arch.upper()}",
    )

    # ── Save final model ──────────────────────────────────────────────────
    final_path = os.path.join(cfg.output_dir, f"final_{args.arch}.keras")
    model.save(final_path)

    # Save model info
    model_info = {
        "architecture": args.arch,
        "language": args.language,
        "sign_classes": dataset.sign_classes,
        "num_classes": num_classes,
        "accuracy": metrics["accuracy"],
        "top3_accuracy": metrics["top3_accuracy"],
        "total_parameters": int(model.count_params()),
        "epochs_trained": len(history.history["accuracy"]),
        "sequence_length": cfg.sequence_length,
        "num_landmarks": cfg.num_landmarks,
    }
    info_path = os.path.join(cfg.output_dir, f"{args.arch}_model_info.json")
    with open(info_path, "w") as f:
        json.dump(model_info, f, indent=2)

    # ── Summary ───────────────────────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  🎉  TRAINING COMPLETE — {args.arch.upper()}")
    print(f"{'═' * 60}")
    print(f"  Accuracy : {metrics['accuracy'] * 100:.2f}%")
    print(f"  Top-3    : {metrics['top3_accuracy'] * 100:.2f}%")
    print(f"  Params   : {model.count_params():,}")
    print(f"\n  Saved    : {final_path}")
    print(f"           : {info_path}")
    print(f"{'═' * 60}\n")


if __name__ == "__main__":
    main()
