# scripts/train_on_landmarks.py
import os, glob, argparse, pickle, numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tqdm import tqdm

def load_all_npy(folder):
    X, y = [], []
    for path in glob.glob(os.path.join(folder, "*.npy")):
        arr = np.load(path, allow_pickle=True)  # shape (num_windows, T, D)
        base = os.path.splitext(os.path.basename(path))[0]
        # infer label from filename pattern or metadata; simplest: folder structure label in parent path
        # assume filename like label__videoid.npy or you have metadata.json - here we assume parent folder mapping not used
        # for robustness, require a metadata file
        X.append(arr)
    if not X:
        return None, None
    X = np.vstack(X)  # (N, T, D)
    return X

def build_model(seq_len, feat_dim, n_classes):
    inp = keras.Input((seq_len, feat_dim))
    x = layers.Masking()(inp)
    x = layers.LSTM(256, return_sequences=True)(x)
    x = layers.Dropout(0.4)(x)
    x = layers.LSTM(128)(x)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(128, activation="relu")(x)
    out = layers.Dense(n_classes, activation="softmax")(x)
    model = keras.Model(inp, out)
    return model

def main(args):
    landmarks_dir = args.landmarks
    # require a metadata.json mapping .npy -> label, created by preprocess script
    import json
    meta_path = os.path.join(landmarks_dir, "metadata.json")
    if not os.path.exists(meta_path):
        raise SystemExit("metadata.json missing in landmarks dir. Run preprocess_videos.py first.")
    with open(meta_path, "r") as f:
        meta = json.load(f)
    samples = meta["samples"]  # list of tuples (label, video_base, window_index)

    X_list, y_list = [], []
    # Load per-video npy once and fetch windows by index
    video_cache = {}
    for label, video_base, idx in tqdm(samples, desc="Loading samples"):
        npy_path = os.path.join(landmarks_dir, f"{video_base}.npy")
        if video_base not in video_cache:
            video_cache[video_base] = np.load(npy_path, allow_pickle=True)
        windows = video_cache[video_base]
        # safety
        if idx < windows.shape[0]:
            X_list.append(windows[idx])
            y_list.append(label)
    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list)
    print("X shape:", X.shape, "y shape:", y.shape)

    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    n_classes = len(le.classes_)
    with open(os.path.join(args.out, "label_encoder.pkl"), "wb") as f:
        pickle.dump(le, f)

    X_train, X_val, y_train, y_val = train_test_split(X, y_enc, test_size=0.2, stratify=y_enc, random_state=42)

    batch = args.batch
    train_ds = tf.data.Dataset.from_tensor_slices((X_train, y_train)).shuffle(1024).batch(batch).prefetch(tf.data.AUTOTUNE)
    val_ds = tf.data.Dataset.from_tensor_slices((X_val, y_val)).batch(batch).prefetch(tf.data.AUTOTUNE)

    model = build_model(X.shape[1], X.shape[2], n_classes)
    model.compile(optimizer=keras.optimizers.Adam(1e-4),
              loss="sparse_categorical_crossentropy",
              metrics=["accuracy", tf.keras.metrics.SparseTopKCategoricalAccuracy(k=3, name='top_3_accuracy')])

    os.makedirs(args.out, exist_ok=True)
    ckpt = keras.callbacks.ModelCheckpoint(os.path.join(args.out, "best_model.keras"), save_best_only=True, monitor="val_accuracy", mode="max")
    es = keras.callbacks.EarlyStopping(monitor="val_accuracy", patience=8, restore_best_weights=True)
    rl = keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4, min_lr=1e-6)
    tb = keras.callbacks.TensorBoard(log_dir=os.path.join("logs"))

    model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=[ckpt, es, rl, tb])
    model.save(os.path.join(args.out, "final_model.keras"))
    # Save some info
    import json
    info = {"n_classes": n_classes, "classes": le.classes_.tolist()}
    with open(os.path.join(args.out, "model_info.json"), "w") as f:
        json.dump(info, f)
    print("Training finished. Models saved to", args.out)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--landmarks", required=True, help="folder with .npy and metadata.json")
    p.add_argument("--out", default="models", help="output folder")
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--epochs", type=int, default=50)
    args = p.parse_args()
    main(args)
