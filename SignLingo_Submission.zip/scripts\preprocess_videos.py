# scripts/preprocess_videos.py
import os, sys, argparse, json
from glob import glob
import numpy as np
import cv2
from tqdm import tqdm
import mediapipe as mp

mp_hands = mp.solutions.hands

SEQUENCE_LENGTH = 30   # frames per sample
FEATURE_DIM = 21 * 3

def extract_landmarks_from_frame(image, hands):
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    res = hands.process(image_rgb)
    if not res.multi_hand_landmarks:
        return None
    lm = res.multi_hand_landmarks[0]
    coords = []
    for p in lm.landmark:
        coords.extend([p.x, p.y, p.z])
    return coords

def process_video(video_path, out_dir, seq_len=SEQUENCE_LENGTH):
    cap = cv2.VideoCapture(video_path)
    frames_landmarks = []
    with mp_hands.Hands(static_image_mode=False, max_num_hands=1,
                        min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            lm = extract_landmarks_from_frame(frame, hands)
            if lm is not None:
                frames_landmarks.append(lm)
    cap.release()

    if len(frames_landmarks) < seq_len:
        return []  # skip short videos (or optionally pad)
    sequences = []
    for i in range(len(frames_landmarks) - seq_len + 1):
        seq = np.array(frames_landmarks[i:i+seq_len], dtype=np.float32)  # (T, D)
        sequences.append(seq)
    # Save per video (npy) for reuse
    if sequences:
        base = os.path.splitext(os.path.basename(video_path))[0]
        np.save(os.path.join(out_dir, f"{base}.npy"), np.array(sequences))
    return sequences

def main(args):
    videos_root = args.videos
    out_dir = args.out
    os.makedirs(out_dir, exist_ok=True)

    # assume structure: videos_root/<label>/*.mp4
    label_dirs = sorted([d for d in glob(os.path.join(videos_root, "*")) if os.path.isdir(d)])
    metadata = []
    for label_dir in label_dirs:
        label = os.path.basename(label_dir)
        files = glob(os.path.join(label_dir, "*.mp4"))
        for vf in tqdm(files, desc=f"Label: {label}"):
            sequences = process_video(vf, out_dir)
            for i in range(len(sequences)):
                metadata.append((label, os.path.splitext(os.path.basename(vf))[0], i))
    # Save a small metadata file mapping npy files -> labels
    with open(os.path.join(out_dir, "metadata.json"), "w") as f:
        json.dump({"samples": metadata}, f)
    print("Done. Preprocessed files saved to:", out_dir)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--videos", required=True, help="root folder with label subfolders containing videos")
    p.add_argument("--out", required=True, help="output folder for .npy files")
    args = p.parse_args()
    main(args)
