#!/usr/bin/env python3
"""
scripts/benchmark.py — Multi-model comparison benchmark for SignLingo.

Trains all supported architectures on the same data split and generates
a comparison chart + results table.

Usage
-----
    # Full benchmark (all 5 architectures)
    python scripts/benchmark.py

    # Quick benchmark (subset)
    python scripts/benchmark.py --archs vit lstm_attention resnet50

    # Custom settings
    python scripts/benchmark.py --epochs 50 --data-dir data/organized
"""

import os
import sys
import json
import argparse
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.config import get_config
from signlingo.data.dataset import SignLanguageDataset
from signlingo.data.preprocessing import preprocess_pipeline
from signlingo.models import build_model
from signlingo.utils.metrics import compute_metrics
from signlingo.utils.visualization import plot_model_comparison


ALL_ARCHS = ["vit", "lstm_attention", "resnet50", "vgg16", "vgg19"]

DISPLAY_NAMES = {
    "vit": "ViT",
    "lstm_attention": "BiLSTM+Attn",
    "resnet50": "ResNet-50",
    "vgg16": "VGG-16",
    "vgg19": "VGG-19",
}


def parse_args():
    p = argparse.ArgumentParser(description="SignLingo — Multi-Model Benchmark")
    p.add_argument("--archs", nargs="+", default=ALL_ARCHS,
                   choices=ALL_ARCHS,
                   help="Architectures to benchmark")
    p.add_argument("--data-dir", default="data/organized")
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=0.0005)
    p.add_argument("--results-dir", default="results")
    p.add_argument("--output-dir", default="models")
    return p.parse_args()


def train_single(arch, num_classes, X_train, y_train, X_test, y_test,
                 class_names, cfg):
    """Train and evaluate one architecture. Returns metrics dict."""
    print(f"\n{'━' * 60}")
    print(f"  🏗️   Training: {DISPLAY_NAMES.get(arch, arch)}")
    print(f"{'━' * 60}")

    model = build_model(num_classes, arch=arch, config=cfg)

    optimizer = keras.optimizers.Adam(learning_rate=cfg.learning_rate)
    model.compile(
        optimizer=optimizer,
        loss="categorical_crossentropy",
        metrics=["accuracy", keras.metrics.TopKCategoricalAccuracy(
            k=min(3, num_classes), name="top_3_accuracy")],
    )

    callbacks = [
        EarlyStopping(
            monitor="val_loss", patience=cfg.patience,
            restore_best_weights=True, verbose=0,
        ),
        ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=5, min_lr=1e-7, verbose=0,
        ),
    ]

    history = model.fit(
        X_train, y_train,
        validation_split=cfg.validation_split,
        epochs=cfg.epochs,
        batch_size=cfg.batch_size,
        callbacks=callbacks,
        verbose=1,
    )

    # Evaluate
    y_pred_probs = model.predict(X_test, verbose=0)
    y_pred = np.argmax(y_pred_probs, axis=1)
    y_true = np.argmax(y_test, axis=1)

    metrics = compute_metrics(y_true, y_pred, y_pred_probs, class_names)
    metrics["params"] = int(model.count_params())
    metrics["epochs"] = len(history.history["accuracy"])
    metrics["model_name"] = DISPLAY_NAMES.get(arch, arch)

    # Save model
    save_path = os.path.join(cfg.output_dir, f"benchmark_{arch}.keras")
    model.save(save_path)

    print(f"  ✅  {DISPLAY_NAMES.get(arch, arch)}: "
          f"{metrics['accuracy'] * 100:.2f}% "
          f"(Top-3: {metrics['top3_accuracy'] * 100:.2f}%) "
          f"— {metrics['params']:,} params")

    # Cleanup to free memory
    del model
    keras.backend.clear_session()

    return metrics


def main():
    args = parse_args()

    cfg = get_config(
        data_dir=args.data_dir,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        output_dir=args.output_dir,
        results_dir=args.results_dir,
    )
    cfg.ensure_dirs()

    # ── GPU setup ─────────────────────────────────────────────────────────
    gpus = tf.config.list_physical_devices("GPU")
    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True)

    # ── Load data (shared across all models) ──────────────────────────────
    print(f"\n{'═' * 60}")
    print("  📂  Loading dataset (shared split)")
    print(f"{'═' * 60}")

    dataset = SignLanguageDataset(cfg)
    dataset.load()

    X_train, y_train = preprocess_pipeline(
        dataset.X_train, dataset.y_train, config=cfg,
    )
    X_test = dataset.X_test
    y_test = dataset.y_test
    num_classes = len(dataset.sign_classes)

    print(f"  Classes : {num_classes}")
    print(f"  Train   : {len(X_train)}  |  Test: {len(X_test)}")

    # ── Benchmark each architecture ───────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  🏆  Benchmarking {len(args.archs)} architectures")
    print(f"{'═' * 60}")

    results = {}
    for arch in args.archs:
        metrics = train_single(
            arch, num_classes, X_train, y_train, X_test, y_test,
            dataset.sign_classes, cfg,
        )
        results[DISPLAY_NAMES.get(arch, arch)] = metrics

    # ── Results summary ───────────────────────────────────────────────────
    print(f"\n\n{'═' * 60}")
    print("  🏆  BENCHMARK RESULTS")
    print(f"{'═' * 60}")
    print(f"  {'Model':<18} {'Accuracy':>10} {'Top-3':>10} {'Params':>12} {'Epochs':>8}")
    print(f"  {'─' * 58}")
    for name, m in sorted(results.items(), key=lambda x: x[1]["accuracy"], reverse=True):
        print(f"  {name:<18} {m['accuracy']*100:>9.2f}% {m['top3_accuracy']*100:>9.2f}% "
              f"{m['params']:>11,} {m['epochs']:>7}")
    print(f"{'═' * 60}")

    # ── Save comparison chart ─────────────────────────────────────────────
    chart_results = {
        name: {
            "accuracy": m["accuracy"],
            "top3_accuracy": m["top3_accuracy"],
            "params": m["params"],
        }
        for name, m in results.items()
    }

    plot_model_comparison(
        chart_results,
        save_path=os.path.join(cfg.results_dir, "model_comparison.png"),
    )

    # Save raw results as JSON
    json_results = {}
    for name, m in results.items():
        json_results[name] = {
            "accuracy": m["accuracy"],
            "top3_accuracy": m["top3_accuracy"],
            "params": m["params"],
            "epochs": m["epochs"],
        }

    results_path = os.path.join(cfg.results_dir, "benchmark_results.json")
    with open(results_path, "w") as f:
        json.dump(json_results, f, indent=2)
    print(f"  💾  Saved: {results_path}")

    print(f"\n  🎉  Benchmark complete!\n")


if __name__ == "__main__":
    main()
