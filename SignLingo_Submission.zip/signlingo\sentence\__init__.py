"""
signlingo.sentence — Sentence formation from recognized sign glosses.
"""

from .formation import SentenceFormer

__all__ = ["SentenceFormer"]
