#!/usr/bin/env python3
"""
Train a denoising autoencoder on Sign Language MNIST.

The encoder compresses each 28×28 letter crop into a 32-number code. The
decoder rebuilds the clean hand from that code. Training inputs are the same
crops with Gaussian noise; the target is the clean crop. The hold-out split
matches scripts/train_alphabet.py (stratified 80/20, seed 42).

Usage
-----
    python scripts/train_autoencoder.py
"""

from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.models.alphabet_cnn import ASL_LETTERS
from signlingo.models.sign_autoencoder import (
    LATENT_DIM,
    NOISE_STD,
    build_sign_autoencoder,
    corrupt_signs,
    reconstruction_mse,
    scale_pixels,
)

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from train_alphabet import ensure_csv, load_arrays  # noqa: E402

MODEL_PATH = os.path.join(ROOT, "models", "sign_autoencoder.keras")
METRICS_PATH = os.path.join(ROOT, "results", "autoencoder_metrics.json")
GRID_PATH = os.path.join(ROOT, "results", "autoencoder_reconstructions.png")


def main():
    from sklearn.model_selection import train_test_split
    from tensorflow import keras
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(os.path.join(ROOT, "models"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)

    x, y = load_arrays(ensure_csv())
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42, stratify=y
    )
    clean_train = scale_pixels(x_train)
    clean_test = scale_pixels(x_test)
    rng = np.random.default_rng(42)
    noisy_test = corrupt_signs(clean_test, NOISE_STD, rng)
    print(f"Train images: {len(clean_train)}   Hold-out images: {len(clean_test)}")

    import tensorflow as tf

    autoencoder, _, _ = build_sign_autoencoder(LATENT_DIM)
    autoencoder.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse")

    def add_noise(image, label):
        # Each sample gets its own noise level, including zero, so a clean
        # crop and a noisy crop are both in the training distribution.
        std = tf.random.uniform((), 0.0, NOISE_STD)
        noise = tf.random.normal(tf.shape(image), stddev=std)
        noisy = tf.clip_by_value(image + noise, 0.0, 1.0)
        return noisy, image

    dataset = tf.data.Dataset.from_tensor_slices((clean_train, y_train))
    dataset = dataset.shuffle(len(clean_train), seed=42, reshuffle_each_iteration=True)
    dataset = dataset.map(add_noise, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(256).prefetch(tf.data.AUTOTUNE)

    history = autoencoder.fit(
        dataset,
        validation_data=(noisy_test, clean_test),
        epochs=12,
        shuffle=False,
        callbacks=[
            keras.callbacks.EarlyStopping(
                monitor="val_loss", patience=3, restore_best_weights=True
            )
        ],
        verbose=2,
    )

    rebuilt_noisy = autoencoder.predict(noisy_test, batch_size=256, verbose=0)
    rebuilt_clean = autoencoder.predict(clean_test, batch_size=256, verbose=0)
    noisy_mse = reconstruction_mse(clean_test, noisy_test)
    denoised_mse = reconstruction_mse(clean_test, rebuilt_noisy)
    clean_mse = reconstruction_mse(clean_test, rebuilt_clean)
    print(f"Hold-out noisy MSE:     {noisy_mse:.6f}")
    print(f"Hold-out denoised MSE:  {denoised_mse:.6f}")
    print(f"Hold-out clean recon:   {clean_mse:.6f}")

    autoencoder.save(MODEL_PATH)
    print(f"Saved {MODEL_PATH}")

    # One hold-out example per letter: original, noisy input, reconstruction.
    show = min(8, len(ASL_LETTERS))
    picked = []
    for cls in range(show):
        hits = np.where(y_test == cls)[0]
        if len(hits):
            picked.append(int(hits[0]))
    fig, axes = plt.subplots(3, len(picked), figsize=(1.4 * len(picked), 4.4))
    row_titles = ["Original", "Noisy input", "Reconstructed"]
    rows = [
        clean_test[picked],
        noisy_test[picked],
        rebuilt_noisy[picked],
    ]
    for col, index in enumerate(picked):
        for row, images in enumerate(rows):
            ax = axes[row, col]
            ax.imshow(images[col].reshape(28, 28), cmap="gray", vmin=0, vmax=1)
            ax.set_xticks([])
            ax.set_yticks([])
            if row == 0:
                ax.set_title(ASL_LETTERS[int(y_test[index])])
            if col == 0:
                ax.set_ylabel(row_titles[row])
    fig.suptitle(
        f"Denoising autoencoder   noisy MSE {noisy_mse:.4f}   "
        f"reconstructed MSE {denoised_mse:.4f}"
    )
    fig.tight_layout()
    fig.savefig(GRID_PATH, dpi=140)
    plt.close(fig)

    metrics = {
        "dataset": "Sign Language MNIST (training CSV, public GitHub mirror)",
        "split": "stratified 80/20 hold-out, random_state=42",
        "task": "denoising reconstruction of 28x28 static ASL letter images",
        "train_images": int(len(clean_train)),
        "holdout_images": int(len(clean_test)),
        "latent_dim": LATENT_DIM,
        "noise_std": NOISE_STD,
        "loss": "mse",
        "holdout_noisy_mse": round(noisy_mse, 6),
        "holdout_denoised_mse": round(denoised_mse, 6),
        "holdout_clean_reconstruction_mse": round(clean_mse, 6),
        "denoising_improved": bool(denoised_mse < noisy_mse),
        "epochs_ran": len(history.history["loss"]),
        "final_train_loss": round(float(history.history["loss"][-1]), 6),
        "final_val_loss": round(float(history.history["val_loss"][-1]), 6),
        "model_path": "models/sign_autoencoder.keras",
    }
    with open(METRICS_PATH, "w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)
    print(f"Saved {METRICS_PATH}")
    if not metrics["denoising_improved"]:
        raise SystemExit("Denoised error was not lower than the noisy input error.")


if __name__ == "__main__":
    main()
