"""
signlingo.models.factory
~~~~~~~~~~~~~~~~~~~~~~~~~

Model factory — single entry point to build any supported architecture
by name.
"""

from tensorflow import keras
from typing import Optional

from signlingo.config import SignLingoConfig, get_config
from signlingo.models.lstm_attention import build_lstm_attention_model
from signlingo.models.vit import build_vit_model
from signlingo.models.resnet import build_resnet50_model
from signlingo.models.vgg import build_vgg_model


# Registry maps config string → builder function
MODEL_REGISTRY = {
    "lstm_attention": build_lstm_attention_model,
    "vit":           build_vit_model,
    "resnet50":      build_resnet50_model,
    "vgg16":         lambda n, c=None: build_vgg_model(n, variant="vgg16", config=c),
    "vgg19":         lambda n, c=None: build_vgg_model(n, variant="vgg19", config=c),
}


def build_model(
    num_classes: int,
    arch: Optional[str] = None,
    config: Optional[SignLingoConfig] = None,
) -> keras.Model:
    """
    Build a model by architecture name.

    Parameters
    ----------
    num_classes : int
        Number of output classes.
    arch : str, optional
        Architecture key.  One of ``MODEL_REGISTRY.keys()``.
        Falls back to ``config.model_arch`` if not provided.
    config : SignLingoConfig, optional

    Returns
    -------
    keras.Model
        Un-compiled Keras model.

    Raises
    ------
    ValueError
        If the architecture name is not registered.
    """
    cfg = config or get_config()
    arch = arch or cfg.model_arch

    if arch not in MODEL_REGISTRY:
        raise ValueError(
            f"Unknown architecture '{arch}'. "
            f"Available: {list(MODEL_REGISTRY.keys())}"
        )

    builder = MODEL_REGISTRY[arch]
    model = builder(num_classes, cfg)

    print(f"  🏗️  Built {model.name}  —  {model.count_params():,} parameters")
    return model
