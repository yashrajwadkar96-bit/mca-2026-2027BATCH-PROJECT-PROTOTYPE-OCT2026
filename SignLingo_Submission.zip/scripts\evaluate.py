#!/usr/bin/env python3
"""
scripts/evaluate.py — Evaluate a trained SignLingo model.

Usage
-----
    python scripts/evaluate.py --model models/best_vit.keras
    python scripts/evaluate.py --model models/best_vit.keras --data-dir data/organized
"""

import os
import sys
import argparse
import pickle
import warnings
warnings.filterwarnings("ignore")

import numpy as np
from tensorflow import keras

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.config import get_config
from signlingo.data.dataset import SignLanguageDataset
from signlingo.utils.metrics import evaluate_model
from signlingo.utils.visualization import plot_confusion_matrix
import signlingo.models  # registers custom layers for keras.models.load_model


def parse_args():
    p = argparse.ArgumentParser(description="SignLingo — Model Evaluation")
    p.add_argument("--model", required=True, help="Path to trained model (.keras or .h5)")
    p.add_argument("--data-dir", default="data/organized")
    p.add_argument("--results-dir", default="results")
    p.add_argument("--model-name", default=None,
                   help="Name for output files (auto-detected from path if not set)")
    return p.parse_args()


def main():
    args = parse_args()

    model_name = args.model_name or os.path.splitext(os.path.basename(args.model))[0]

    # Load model
    print(f"📦  Loading model: {args.model}")
    model = keras.models.load_model(args.model, safe_mode=False)
    print(f"  ✅  {model.name} — {model.count_params():,} parameters")

    # Load dataset
    cfg = get_config(data_dir=args.data_dir, results_dir=args.results_dir)
    dataset = SignLanguageDataset(cfg)
    dataset.load()

    # Evaluate
    metrics = evaluate_model(
        model, dataset.X_test, dataset.y_test,
        class_names=dataset.sign_classes,
        results_dir=args.results_dir,
        model_name=model_name,
    )

    # Confusion matrix
    y_pred = np.argmax(model.predict(dataset.X_test, verbose=0), axis=1)
    y_true = np.argmax(dataset.y_test, axis=1)
    plot_confusion_matrix(
        y_true, y_pred,
        class_names=dataset.sign_classes,
        save_path=os.path.join(args.results_dir, f"{model_name}_confusion_matrix.png"),
        title=f"Confusion Matrix — {model_name}",
    )

    print(f"\n  ✅  Evaluation complete for {model_name}")
    print(f"  Accuracy : {metrics['accuracy'] * 100:.2f}%")
    print(f"  Top-3    : {metrics['top3_accuracy'] * 100:.2f}%")


if __name__ == "__main__":
    main()
