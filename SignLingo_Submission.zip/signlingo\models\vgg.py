"""
signlingo.models.vgg
~~~~~~~~~~~~~~~~~~~~

VGG-16 and VGG-19 architectures adapted for 1-D temporal hand-landmark
sequences.

The classic VGG pattern of stacked 3×3 convolutions with max-pooling is
preserved, but all 2-D operations are replaced with 1-D counterparts
operating along the temporal axis of landmark sequences.

Architecture (VGG-16)
---------------------
Input (T, D)
  → 2 × Conv1D(64,  3) + MaxPool
  → 2 × Conv1D(128, 3) + MaxPool
  → 3 × Conv1D(256, 3) + MaxPool
  → 3 × Conv1D(512, 3) + MaxPool
  → 3 × Conv1D(512, 3) + MaxPool
  → GlobalAvgPool → Dense(256) → Dropout → Dense(128) → Dropout
  → Dense(num_classes, softmax)

Reference:
    Simonyan & Zisserman, "Very Deep Convolutional Networks for Large-Scale
    Image Recognition," ICLR 2015.
"""

from tensorflow import keras
from tensorflow.keras import layers, models
from typing import Optional

from signlingo.config import SignLingoConfig, get_config


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _conv_block(x, filters: int, n_convs: int, block_name: str):
    """Stack *n_convs* Conv1D(filters, 3) + BN + ReLU, then MaxPool."""
    for i in range(n_convs):
        x = layers.Conv1D(
            filters, 3, padding="same",
            activation=None,
            name=f"{block_name}_conv{i}",
        )(x)
        x = layers.BatchNormalization(name=f"{block_name}_bn{i}")(x)
        x = layers.Activation("relu", name=f"{block_name}_relu{i}")(x)
    x = layers.MaxPooling1D(2, strides=2, padding="same", name=f"{block_name}_pool")(x)
    return x


# ═══════════════════════════════════════════════════════════════════════════════
# VGG-16 / VGG-19 configs
# ═══════════════════════════════════════════════════════════════════════════════

# Each tuple: (filters, num_conv_layers)
_VGG16_BLOCKS = [(64, 2), (128, 2), (256, 3), (512, 3), (512, 3)]
_VGG19_BLOCKS = [(64, 2), (128, 2), (256, 4), (512, 4), (512, 4)]


# ═══════════════════════════════════════════════════════════════════════════════
# Model builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_vgg_model(
    num_classes: int,
    variant: str = "vgg16",
    config: Optional[SignLingoConfig] = None,
) -> keras.Model:
    """
    Build a 1-D VGG model for temporal landmark classification.

    Parameters
    ----------
    num_classes : int
        Number of sign language classes.
    variant : str
        ``"vgg16"`` or ``"vgg19"``.
    config : SignLingoConfig, optional

    Returns
    -------
    keras.Model
    """
    cfg = config or get_config()
    blocks = _VGG16_BLOCKS if variant == "vgg16" else _VGG19_BLOCKS

    inp = layers.Input(shape=cfg.input_shape, name="landmark_input")
    x = inp

    for idx, (filters, n_convs) in enumerate(blocks):
        x = _conv_block(x, filters, n_convs, block_name=f"block{idx + 1}")

    # Classification head
    x = layers.GlobalAveragePooling1D(name="gap")(x)
    x = layers.Dense(256, activation="relu", name="fc1")(x)
    x = layers.Dropout(0.4, name="fc1_drop")(x)
    x = layers.Dense(128, activation="relu", name="fc2")(x)
    x = layers.Dropout(0.3, name="fc2_drop")(x)
    out = layers.Dense(num_classes, activation="softmax", name="predictions")(x)

    model_name = "VGG16_1D" if variant == "vgg16" else "VGG19_1D"
    model = models.Model(inp, out, name=model_name)
    return model
