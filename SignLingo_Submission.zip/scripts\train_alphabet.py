#!/usr/bin/env python3
"""
Train the ASL fingerspelling CNN on Sign Language MNIST.

The public mirror used here contains the training CSV only (27,455 images).
Metrics below are measured on a stratified 20% hold-out of that file
(random seed 42), not copied from the original README.

Usage
-----
    python scripts/train_alphabet.py
"""

from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from signlingo.models.alphabet_cnn import ASL_LETTERS, build_alphabet_cnn, mnist_label_to_index

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CSV_PATH = os.path.join(ROOT, "data", "sign_mnist", "sign_mnist_train.csv")
MODEL_PATH = os.path.join(ROOT, "models", "alphabet_cnn.keras")
METRICS_PATH = os.path.join(ROOT, "results", "alphabet_metrics.json")
SAMPLES_PATH = os.path.join(ROOT, "results", "alphabet_samples.npz")
CM_PATH = os.path.join(ROOT, "results", "alphabet_confusion_matrix.png")

CSV_URL = (
    "https://raw.githubusercontent.com/"
    "harshitahluwalia7895/MNIST-Signs-dataset/master/sign_mnist_train.csv"
)


def ensure_csv() -> str:
    os.makedirs(os.path.dirname(CSV_PATH), exist_ok=True)
    if os.path.isfile(CSV_PATH) and os.path.getsize(CSV_PATH) > 1_000_000:
        return CSV_PATH
    print(f"Downloading Sign Language MNIST to {CSV_PATH}")
    import requests

    with requests.get(CSV_URL, headers={"User-Agent": "signlingo"}, stream=True, timeout=180) as resp:
        resp.raise_for_status()
        with open(CSV_PATH, "wb") as handle:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                if chunk:
                    handle.write(chunk)
    return CSV_PATH


def load_arrays(path: str):
    import pandas as pd

    frame = pd.read_csv(path)
    labels = frame.iloc[:, 0].to_numpy()
    pixels = frame.iloc[:, 1:].to_numpy(dtype=np.float32)
    y = np.array([mnist_label_to_index(int(v)) for v in labels], dtype=np.int32)
    x = pixels.reshape(-1, 28, 28, 1)
    return x, y


def main():
    from sklearn.metrics import accuracy_score, confusion_matrix, top_k_accuracy_score
    from sklearn.model_selection import train_test_split
    from tensorflow import keras
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(os.path.join(ROOT, "models"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)

    x, y = load_arrays(ensure_csv())
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Train images: {len(x_train)}   Hold-out images: {len(x_test)}")

    model = build_alphabet_cnn(num_classes=len(ASL_LETTERS))
    model.compile(
        optimizer=keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    history = model.fit(
        x_train,
        y_train,
        validation_data=(x_test, y_test),
        epochs=8,
        batch_size=128,
        callbacks=[
            keras.callbacks.EarlyStopping(
                monitor="val_accuracy", patience=2, restore_best_weights=True
            )
        ],
        verbose=2,
    )

    probs = model.predict(x_test, batch_size=256, verbose=0)
    pred = np.argmax(probs, axis=1)
    acc = float(accuracy_score(y_test, pred))
    top3 = float(top_k_accuracy_score(y_test, probs, k=3, labels=list(range(len(ASL_LETTERS)))))
    print(f"Hold-out accuracy: {acc:.4f}")
    print(f"Hold-out top-3:    {top3:.4f}")

    model.save(MODEL_PATH)
    print(f"Saved {MODEL_PATH}")

    cm = confusion_matrix(y_test, pred, labels=list(range(len(ASL_LETTERS))))
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(ASL_LETTERS)), ASL_LETTERS)
    ax.set_yticks(range(len(ASL_LETTERS)), ASL_LETTERS)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(f"ASL fingerspelling CNN  —  hold-out accuracy {acc:.1%}")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(CM_PATH, dpi=140)
    plt.close(fig)

    # One example of each letter for the app gallery, taken from the hold-out set.
    sample_x, sample_y = [], []
    for cls in range(len(ASL_LETTERS)):
        hits = np.where(y_test == cls)[0]
        if len(hits):
            sample_x.append(x_test[hits[0]])
            sample_y.append(cls)
    np.savez_compressed(
        SAMPLES_PATH,
        images=np.stack(sample_x).astype(np.uint8),
        labels=np.array(sample_y, dtype=np.int32),
    )

    metrics = {
        "dataset": "Sign Language MNIST (training CSV, public GitHub mirror)",
        "split": "stratified 80/20 hold-out, random_state=42",
        "train_images": int(len(x_train)),
        "holdout_images": int(len(x_test)),
        "classes": ASL_LETTERS,
        "excluded": ["J", "Z"],
        "exclusion_reason": "J and Z are motion signs and are not in Sign Language MNIST.",
        "holdout_accuracy": round(acc, 4),
        "holdout_top3_accuracy": round(top3, 4),
        "epochs_ran": len(history.history["accuracy"]),
        "final_train_accuracy": round(float(history.history["accuracy"][-1]), 4),
        "final_val_accuracy": round(float(history.history["val_accuracy"][-1]), 4),
        "model_path": "models/alphabet_cnn.keras",
    }
    with open(METRICS_PATH, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    print(f"Saved {METRICS_PATH}")


if __name__ == "__main__":
    main()
