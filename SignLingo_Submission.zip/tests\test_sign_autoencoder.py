"""Forward pass and a short training step for the sign autoencoder."""

import numpy as np

from signlingo.models.sign_autoencoder import (
    build_sign_autoencoder,
    corrupt_signs,
    reconstruction_mse,
    scale_pixels,
)


def test_scale_pixels_accepts_mnist_range():
    raw = np.full((2, 28, 28, 1), 255.0, dtype=np.float32)
    scaled = scale_pixels(raw)
    assert scaled.shape == (2, 28, 28, 1)
    assert scaled.max() == 1.0


def test_corrupt_signs_stays_in_unit_interval():
    clean = np.linspace(0, 1, 28 * 28, dtype=np.float32).reshape(1, 28, 28, 1)
    noisy = corrupt_signs(clean, noise_std=1.0, rng=np.random.default_rng(0))
    assert noisy.shape == clean.shape
    assert noisy.min() >= 0.0
    assert noisy.max() <= 1.0


def test_encoder_decoder_round_trip_shapes():
    autoencoder, encoder, decoder = build_sign_autoencoder(latent_dim=16)
    images = np.random.default_rng(0).random((4, 28, 28, 1)).astype(np.float32)
    codes = encoder.predict(images, verbose=0)
    rebuilt = decoder.predict(codes, verbose=0)
    direct = autoencoder.predict(images, verbose=0)
    assert codes.shape == (4, 16)
    assert rebuilt.shape == (4, 28, 28, 1)
    assert direct.shape == rebuilt.shape
    assert direct.min() >= 0.0 and direct.max() <= 1.0
    np.testing.assert_allclose(direct, rebuilt, atol=1e-5)


def test_one_epoch_reduces_reconstruction_error():
    autoencoder, _, _ = build_sign_autoencoder(latent_dim=8)
    autoencoder.compile(optimizer="adam", loss="mse")
    clean = np.zeros((32, 28, 28, 1), dtype=np.float32)
    clean[:, 8:20, 8:20, :] = 1.0
    noisy = corrupt_signs(clean, noise_std=0.3, rng=np.random.default_rng(1))
    before = reconstruction_mse(clean, autoencoder.predict(noisy, verbose=0))
    autoencoder.fit(noisy, clean, epochs=3, batch_size=16, verbose=0)
    after = reconstruction_mse(clean, autoencoder.predict(noisy, verbose=0))
    assert after < before
