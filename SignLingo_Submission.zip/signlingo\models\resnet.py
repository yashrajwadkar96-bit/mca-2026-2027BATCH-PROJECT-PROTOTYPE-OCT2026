"""
signlingo.models.resnet
~~~~~~~~~~~~~~~~~~~~~~~

ResNet-50–style architecture adapted for 1-D temporal hand-landmark sequences.

Instead of 2-D convolutions over images, we use 1-D convolutions along the
temporal axis.  The model preserves the iconic residual-connection pattern
of ResNet-50 (bottleneck blocks with skip connections) while operating on
sequences of shape ``(T, D)``.

Architecture (high level)
-------------------------
Input (T, D) → Conv1D stem (7, 64) → BN → ReLU → MaxPool
  → Stage 1 : 3 × BottleneckBlock(64,  256)
  → Stage 2 : 4 × BottleneckBlock(128, 512)
  → Stage 3 : 6 × BottleneckBlock(256, 1024)
  → Stage 4 : 3 × BottleneckBlock(512, 2048)
  → GlobalAvgPool → Dense(num_classes, softmax)
"""

from tensorflow import keras
from tensorflow.keras import layers, models
from typing import Optional

from signlingo.config import SignLingoConfig, get_config


# ═══════════════════════════════════════════════════════════════════════════════
# Bottleneck block
# ═══════════════════════════════════════════════════════════════════════════════

def _bottleneck_block(x, filters: int, expansion: int = 4,
                      stride: int = 1, name: str = ""):
    """
    1-D Bottleneck residual block.

    Parameters
    ----------
    filters : int
        Number of filters for the narrow (3×) conv.
    expansion : int
        Multiplier for the final 1×1 conv filter count.
    stride : int
        Stride for the middle conv (down-samples temporally if >1).
    """
    shortcut = x
    out_filters = filters * expansion

    # 1×1 reduce
    x = layers.Conv1D(filters, 1, strides=1, padding="same", name=f"{name}_conv1")(x)
    x = layers.BatchNormalization(name=f"{name}_bn1")(x)
    x = layers.Activation("relu", name=f"{name}_relu1")(x)

    # 3×1 conv
    x = layers.Conv1D(filters, 3, strides=stride, padding="same", name=f"{name}_conv2")(x)
    x = layers.BatchNormalization(name=f"{name}_bn2")(x)
    x = layers.Activation("relu", name=f"{name}_relu2")(x)

    # 1×1 expand
    x = layers.Conv1D(out_filters, 1, strides=1, padding="same", name=f"{name}_conv3")(x)
    x = layers.BatchNormalization(name=f"{name}_bn3")(x)

    # Shortcut projection if dimensions change
    if stride != 1 or shortcut.shape[-1] != out_filters:
        shortcut = layers.Conv1D(
            out_filters, 1, strides=stride, padding="same", name=f"{name}_proj"
        )(shortcut)
        shortcut = layers.BatchNormalization(name=f"{name}_proj_bn")(shortcut)

    x = layers.Add(name=f"{name}_add")([x, shortcut])
    x = layers.Activation("relu", name=f"{name}_out")(x)
    return x


def _resnet_stage(x, filters: int, blocks: int, stride: int = 1,
                  stage_name: str = ""):
    """Stack *blocks* bottleneck blocks. First block may down-sample."""
    x = _bottleneck_block(x, filters, stride=stride, name=f"{stage_name}_block0")
    for i in range(1, blocks):
        x = _bottleneck_block(x, filters, stride=1, name=f"{stage_name}_block{i}")
    return x


# ═══════════════════════════════════════════════════════════════════════════════
# Model builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_resnet50_model(
    num_classes: int,
    config: Optional[SignLingoConfig] = None,
) -> keras.Model:
    """
    Build a 1-D ResNet-50 for temporal landmark classification.

    Parameters
    ----------
    num_classes : int
        Number of sign language classes.
    config : SignLingoConfig, optional

    Returns
    -------
    keras.Model
    """
    cfg = config or get_config()
    inp = layers.Input(shape=cfg.input_shape, name="landmark_input")

    # Stem
    x = layers.Conv1D(64, 7, strides=2, padding="same", name="stem_conv")(inp)
    x = layers.BatchNormalization(name="stem_bn")(x)
    x = layers.Activation("relu", name="stem_relu")(x)
    x = layers.MaxPooling1D(3, strides=2, padding="same", name="stem_pool")(x)

    # Residual stages (ResNet-50 config: 3-4-6-3)
    x = _resnet_stage(x, 64,  blocks=3, stride=1, stage_name="stage1")
    x = _resnet_stage(x, 128, blocks=4, stride=2, stage_name="stage2")
    x = _resnet_stage(x, 256, blocks=6, stride=2, stage_name="stage3")
    x = _resnet_stage(x, 512, blocks=3, stride=2, stage_name="stage4")

    # Head
    x = layers.GlobalAveragePooling1D(name="gap")(x)
    x = layers.Dropout(0.3, name="head_drop")(x)
    out = layers.Dense(num_classes, activation="softmax", name="predictions")(x)

    model = models.Model(inp, out, name="ResNet50_1D")
    return model
