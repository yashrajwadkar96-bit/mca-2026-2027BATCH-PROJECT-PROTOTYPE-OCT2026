"""
ASL fingerspelling from MediaPipe hand landmarks.

The pixel CNN was trained on Sign Language MNIST, which does not look like a
webcam photo, so live predictions from that network are unreliable. This
classifier uses the 21 hand landmarks instead: finger extension, thumb
position, and whether the palm faces the camera. J and Z are omitted because
they require motion.
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from signlingo.models.alphabet_cnn import ASL_LETTERS

_FINGERS = {
    "index": (5, 6, 8),
    "middle": (9, 10, 12),
    "ring": (13, 14, 16),
    "pinky": (17, 18, 20),
}


def _blank_scores() -> Dict[str, float]:
    return {letter: 0.0 for letter in ASL_LETTERS}


def top_k(probs: np.ndarray, k: int = 3):
    order = np.argsort(probs)[::-1][:k]
    return [(ASL_LETTERS[int(i)], float(probs[int(i)])) for i in order]


def predict_landmarks(landmarks: np.ndarray) -> Tuple[str, float, np.ndarray]:
    """Return letter, confidence, and a 24-length score vector."""
    lm = np.asarray(landmarks, dtype=np.float32)
    scores = _score(lm)
    order = sorted(scores, key=scores.get, reverse=True)
    best = order[0]
    confidence = float(scores[best])
    second = float(scores[order[1]])
    # If two letters are close, the pose is ambiguous. Drop confidence so the
    # speller does not commit a guess.
    if confidence - second < 0.12:
        confidence = min(confidence, 0.45)
    vector = np.array([scores[letter] for letter in ASL_LETTERS], dtype=np.float32)
    total = float(vector.sum()) + 1e-6
    probs = vector / total
    return best, confidence, probs


def _score(lm: np.ndarray) -> Dict[str, float]:
    scores = _blank_scores()
    wrist = lm[0, :2]
    axis = lm[9, :2] - wrist
    palm = float(np.linalg.norm(axis)) + 1e-6
    axis_n = axis / palm
    side = lm[5, :2] - lm[17, :2]
    side_n = side / (float(np.linalg.norm(side)) + 1e-6)

    def along(index: int) -> float:
        return float(np.dot(lm[index, :2] - wrist, axis_n))

    def lateral(index: int) -> float:
        return float(np.dot(lm[index, :2] - wrist, side_n))

    def nd(i: int, j: int) -> float:
        return float(np.linalg.norm(lm[i, :2] - lm[j, :2]) / palm)

    extended = {}
    for name, (mcp, pip, tip) in _FINGERS.items():
        extended[name] = (along(tip) - along(pip)) > 0.12 * palm

    n_ext = sum(extended.values())
    pointing_down = float(lm[9, 1] - lm[0, 1]) > 0.25 * palm
    v1 = lm[5] - lm[0]
    v2 = lm[17] - lm[0]
    normal = np.cross(v1, v2)
    facing = abs(float(normal[2])) > 0.45 * float(np.linalg.norm(normal[:2]) + 1e-6)

    pinch = nd(4, 8) < 0.42
    tip_ids = (8, 12, 16, 20)
    tip_cluster = max(nd(a, b) for a in tip_ids for b in tip_ids)
    closed_o = n_ext == 0 and tip_cluster < 0.38 and nd(4, 8) < 0.45
    thumb_out = lateral(4) > lateral(5) + 0.22 * palm
    thumb_with_index = abs(lateral(4) - lateral(8)) < 0.38 * palm and along(4) > 0.55 * palm
    tip_gap = nd(8, 12)
    spread = tip_gap > 0.5
    together = tip_gap < 0.42
    crossed = extended["index"] and extended["middle"] and (
        (lateral(5) - lateral(9)) * (lateral(8) - lateral(12)) < 0
    )
    index_hook = (
        not extended["index"]
        and (along(6) - along(5)) > 0.18 * palm
        and along(8) < along(6) - 0.05 * palm
        and not extended["middle"]
        and not extended["ring"]
        and not extended["pinky"]
    )

    only = {name: extended[name] and n_ext == 1 for name in extended}
    two_index_middle = (
        extended["index"] and extended["middle"] and not extended["ring"] and not extended["pinky"]
    )

    if pinch and extended["middle"] and extended["ring"] and extended["pinky"] and not extended["index"]:
        scores["F"] = 0.93
    if closed_o:
        scores["O"] = 0.9
    if extended["pinky"] and thumb_out and n_ext == 1:
        scores["Y"] = 0.93
    if only["pinky"] and not thumb_out:
        scores["I"] = 0.9
    if extended["index"] and extended["middle"] and extended["ring"] and not extended["pinky"]:
        scores["W"] = 0.92
    if n_ext == 4 and not thumb_out:
        scores["B"] = 0.92
    if crossed:
        scores["R"] = 0.9
    if two_index_middle and spread and thumb_out and not pointing_down:
        scores["K"] = 0.88
    if two_index_middle and spread and thumb_out and pointing_down:
        scores["P"] = 0.88
    if two_index_middle and spread and not thumb_out:
        scores["V"] = 0.92
    if two_index_middle and together and not facing:
        scores["H"] = 0.86
    if two_index_middle and together and facing:
        scores["U"] = 0.9

    if only["index"] and thumb_out and not thumb_with_index and not pointing_down:
        scores["L"] = 0.93
    if only["index"] and thumb_with_index and not facing and not pointing_down:
        scores["G"] = 0.86
    if only["index"] and thumb_with_index and not facing and pointing_down:
        scores["Q"] = 0.84
    if only["index"] and not thumb_out and nd(4, 10) < 0.7:
        scores["D"] = 0.86
    if index_hook:
        scores["X"] = 0.84

    # Open curve: closed fingers, thumb held away from the index fingertip.
    if n_ext == 0 and not closed_o and not index_hook and thumb_out and nd(4, 8) > 0.65:
        scores["C"] = 0.86

    if n_ext == 0 and not closed_o and not index_hook and scores["C"] < 0.5:
        d_index, d_middle, d_ring = nd(4, 5), nd(4, 9), nd(4, 13)
        tip_distances = [nd(4, tip) for tip in (8, 12, 16, 20)]
        if max(tip_distances) < 0.48 and d_ring > d_index:
            scores["E"] = 0.78
        elif thumb_out or (d_index + 0.08 < d_middle and d_index < 0.85):
            scores["A"] = 0.8
        elif d_index < 0.30 and d_middle < 0.30 and d_ring > d_middle + 0.08:
            scores["T"] = 0.74
        elif d_ring + 0.05 < d_index and d_ring < d_middle:
            scores["M"] = 0.74
        elif abs(d_middle - d_ring) < 0.08 and d_index > d_middle + 0.12 and d_ring < 0.45:
            scores["N"] = 0.72
        else:
            scores["S"] = 0.7

    if max(scores.values()) <= 0:
        scores["S"] = 0.35
    return scores
