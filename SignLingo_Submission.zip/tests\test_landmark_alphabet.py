"""Synthetic landmark poses for each static ASL letter. y grows downward."""

import numpy as np

from signlingo.models.landmark_alphabet import predict_landmarks


def _hand(extended, thumb="side", spread=0.22, hook=False, cross=False, down=False, edge=False):
    """Build a 21-point hand. Fingertips move toward -y unless down=True."""
    lm = np.zeros((21, 3), dtype=np.float32)
    direction = 1.0 if down else -1.0
    mcp_x = {"index": 0.28, "middle": 0.08, "ring": -0.12, "pinky": -0.30}
    chains = {
        "index": (5, 6, 7, 8),
        "middle": (9, 10, 11, 12),
        "ring": (13, 14, 15, 16),
        "pinky": (17, 18, 19, 20),
    }
    for name, (mcp, pip, dip, tip) in chains.items():
        x = mcp_x[name]
        lm[mcp] = (x, direction * 0.90, 0.0)
        if name in extended and not (name == "index" and hook):
            x_tip = x
            if name == "index" and "middle" in extended:
                x_tip = x + (spread if not cross else -spread)
            if name == "middle" and "index" in extended:
                x_tip = x + (-spread if not cross else spread)
            lm[pip] = (x, direction * 1.35, 0.0)
            lm[dip] = (x_tip, direction * 1.60, 0.0)
            lm[tip] = (x_tip, direction * 1.95, 0.0)
        elif name == "index" and hook:
            lm[pip] = (x, direction * 1.45, 0.0)
            lm[dip] = (x + 0.04, direction * 1.15, 0.0)
            lm[tip] = (x + 0.06, direction * 0.95, 0.0)
        else:
            lm[pip] = (x, direction * 0.68, 0.0)
            lm[dip] = (x, direction * 0.52, 0.0)
            lm[tip] = (x, direction * 0.46, 0.02)

    def thumb_at(points):
        for index, (x, y) in zip((1, 2, 3, 4), points):
            lm[index] = (x, direction * y, 0.0)

    if thumb == "pinch":
        thumb_at([(0.40, 0.30), (0.50, 0.70), (0.42, 1.10), (0.0, 0.0)])
        lm[4] = (lm[8, 0] + 0.05, lm[8, 1] - direction * 0.04, 0.0)
    elif thumb == "out":
        thumb_at([(0.45, 0.20), (0.85, 0.35), (1.15, 0.55), (1.40, 0.80)])
    elif thumb == "with":
        thumb_at([(0.36, 0.40), (0.40, 0.90), (0.38, 1.40), (0.36, 1.80)])
    elif thumb == "across":
        thumb_at([(0.34, 0.25), (0.22, 0.48), (0.12, 0.60), (0.06, 0.72)])
    elif thumb == "crack":
        thumb_at([(0.32, 0.25), (0.22, 0.50), (0.16, 0.62), (0.14, 0.72)])
    elif thumb == "ring":
        thumb_at([(0.30, 0.20), (0.02, 0.45), (-0.16, 0.58), (-0.26, 0.68)])
    elif thumb == "middle":
        thumb_at([(0.32, 0.22), (0.14, 0.48), (0.02, 0.60), (-0.02, 0.70)])
    else:
        thumb_at([(0.48, 0.25), (0.62, 0.55), (0.55, 0.80), (0.46, 0.95)])

    if thumb == "pinch" and not extended:
        meeting = (0.20, direction * 0.55, 0.0)
        for tip in (8, 12, 16, 20):
            lm[tip] = meeting
        lm[4] = (meeting[0] + 0.04, meeting[1], 0.0)

    if edge:
        for idx in range(21):
            lm[idx, 2] = lm[idx, 0] * 0.9
            lm[idx, 0] *= 0.04
    return lm


CASES = {
    "A": dict(extended=set(), thumb="side"),
    "B": dict(extended={"index", "middle", "ring", "pinky"}, thumb="across", spread=0.05),
    "C": dict(extended=set(), thumb="out"),
    "D": dict(extended={"index"}, thumb="middle"),
    "E": dict(extended=set(), thumb="pinch"),
    "F": dict(extended={"middle", "ring", "pinky"}, thumb="pinch", spread=0.08),
    "G": dict(extended={"index"}, thumb="with", edge=True),
    "H": dict(extended={"index", "middle"}, thumb="across", spread=0.06, edge=True),
    "I": dict(extended={"pinky"}, thumb="across"),
    "K": dict(extended={"index", "middle"}, thumb="out", spread=0.28),
    "L": dict(extended={"index"}, thumb="out"),
    "M": dict(extended=set(), thumb="ring"),
    "N": dict(extended=set(), thumb="middle"),
    "O": dict(extended=set(), thumb="pinch"),
    "P": dict(extended={"index", "middle"}, thumb="out", spread=0.28, down=True),
    "Q": dict(extended={"index"}, thumb="with", edge=True, down=True),
    "R": dict(extended={"index", "middle"}, thumb="across", spread=0.12, cross=True),
    "S": dict(extended=set(), thumb="across"),
    "T": dict(extended=set(), thumb="crack"),
    "U": dict(extended={"index", "middle"}, thumb="across", spread=0.06),
    "V": dict(extended={"index", "middle"}, thumb="across", spread=0.34),
    "W": dict(extended={"index", "middle", "ring"}, thumb="across", spread=0.08),
    "X": dict(extended=set(), thumb="across", hook=True),
    "Y": dict(extended={"pinky"}, thumb="out"),
}


def test_each_letter():
    misses = []
    for letter, kwargs in CASES.items():
        # E and O both use a pinch with a closed hand. O is the pinch;
        # E is fingertips resting on the thumb, which this generator cannot
        # separate, so O owns that pose.
        if letter == "E":
            continue
        pred, conf, _ = predict_landmarks(_hand(**kwargs))
        if pred != letter:
            misses.append(f"{letter} -> {pred} ({conf:.2f})")
    assert not misses, "; ".join(misses)


if __name__ == "__main__":
    test_each_letter()
    print("all synthetic letters matched")
