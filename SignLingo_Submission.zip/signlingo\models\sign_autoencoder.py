"""
Denoising convolutional autoencoder for static ASL letter images.

Sign Language MNIST hands are 28×28 grayscale crops. This encoder-decoder
compresses each crop into a short latent code and rebuilds the hand. It is
trained to recover the clean crop from a noisy copy, which is the usual
autoencoder use of this dataset: drop pixel noise while keeping the letter shape.

Input and output are float images in ``[0, 1]`` with shape ``(28, 28, 1)``.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np
from tensorflow import keras
from tensorflow.keras import layers

LATENT_DIM = 32
IMAGE_SHAPE = (28, 28, 1)
NOISE_STD = 0.25


def scale_pixels(images: np.ndarray) -> np.ndarray:
    """Map 0–255 pixel crops to ``[0, 1]`` with shape ``(..., 28, 28, 1)``."""
    arr = np.asarray(images, dtype=np.float32)
    if arr.ndim == 2 and arr.shape[1] == 784:
        arr = arr.reshape(-1, 28, 28, 1)
    elif arr.ndim == 2 and arr.shape == (28, 28):
        arr = arr.reshape(1, 28, 28, 1)
    elif arr.ndim == 3 and arr.shape[-2:] == (28, 28):
        arr = arr[..., None]
    if arr.size and float(np.max(arr)) > 1.0:
        arr = arr / 255.0
    return np.clip(arr, 0.0, 1.0)


def corrupt_signs(
    images: np.ndarray,
    noise_std: float = NOISE_STD,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """Add Gaussian noise to ``[0, 1]`` sign images and clip back to that range."""
    clean = np.asarray(images, dtype=np.float32)
    generator = rng if rng is not None else np.random.default_rng()
    noise = generator.normal(0.0, noise_std, size=clean.shape).astype(np.float32)
    return np.clip(clean + noise, 0.0, 1.0)


def reconstruction_mse(original: np.ndarray, reconstructed: np.ndarray) -> float:
    """Mean squared error between two image batches."""
    left = np.asarray(original, dtype=np.float32)
    right = np.asarray(reconstructed, dtype=np.float32)
    return float(np.mean((left - right) ** 2))


def build_sign_autoencoder(
    latent_dim: int = LATENT_DIM,
) -> Tuple[keras.Model, keras.Model, keras.Model]:
    """
    Build the autoencoder plus its encoder and decoder.

    The decoder is a nested model, so a saved autoencoder still exposes it
    under the name ``sign_decoder``.
    """
    if latent_dim < 2:
        raise ValueError("latent_dim must be at least 2")

    image = keras.Input(shape=IMAGE_SHAPE, name="sign_image")
    x = layers.Conv2D(32, 3, padding="same", activation="relu")(image)
    x = layers.MaxPooling2D(name="pool_14")(x)
    x = layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D(name="pool_7")(x)
    x = layers.Flatten()(x)
    latent = layers.Dense(latent_dim, name="latent")(x)
    encoder = keras.Model(image, latent, name="sign_encoder")

    code = keras.Input(shape=(latent_dim,), name="latent_code")
    y = layers.Dense(7 * 7 * 64, activation="relu")(code)
    y = layers.Reshape((7, 7, 64))(y)
    y = layers.Conv2DTranspose(64, 3, strides=2, padding="same", activation="relu")(y)
    y = layers.Conv2DTranspose(32, 3, strides=2, padding="same", activation="relu")(y)
    reconstruction = layers.Conv2D(
        1, 3, padding="same", activation="sigmoid", name="reconstruction"
    )(y)
    decoder = keras.Model(code, reconstruction, name="sign_decoder")

    autoencoder = keras.Model(image, decoder(encoder(image)), name="sign_autoencoder")
    return autoencoder, encoder, decoder
