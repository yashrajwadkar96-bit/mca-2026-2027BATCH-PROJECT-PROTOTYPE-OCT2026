"""
signlingo.data.landmark_extractor
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Enhanced hand landmark extractor using MediaPipe Hands.

Improvements over v1
--------------------
* **Dual-hand support** — left and right hands are extracted separately and
  assigned to fixed slots using MediaPipe handedness labels.  Single-hand
  signs still work; the missing hand slot is zero-filled.
* **Wrist-relative normalization** — each hand's 21 landmarks are translated
  so the wrist sits at the origin, then scaled by the maximum inter-landmark
  distance.  This makes features translation- and scale-invariant, removing
  the camera-distance confound.
* **Inter-hand relative features** — 6 extra values capture the spatial
  relationship between the two hands (relative wrist position + relative
  index-tip position in raw image coords).  These are critical for two-hand
  signs where each hand looks identical in isolation.
* **Confidence gating** — MediaPipe handedness scores below 0.5 are rejected,
  preventing noisy low-confidence detections from polluting the feature vector.
"""

import cv2
import numpy as np
from typing import Optional

from signlingo.config import SignLingoConfig, get_config
from signlingo.data.hands_runtime import HandDetection, HandTracker

_LANDMARK_INDEX_TIP = 8  # MediaPipe hand landmark index for index fingertip


class LandmarkExtractor:
    """
    MediaPipe-based hand landmark extractor.

    With ``use_both_hands=True`` (default), each frame produces:

        left hand  : 21 pts × 3 = 63  (wrist-relative, scale-invariant)
        right hand : 21 pts × 3 = 63  (wrist-relative, scale-invariant)
        inter-hand :              6   (relative wrist + index-tip offsets)
        ─────────────────────────────
        total                    132  features / frame

    With ``use_both_hands=False`` the original 63-feature mode is preserved.
    """

    def __init__(self, config: Optional[SignLingoConfig] = None, mode: str = "video"):
        self.cfg = config or get_config()
        self._hands = HandTracker(
            mode=mode,
            max_hands=self.cfg.max_hands,
            min_detection_confidence=self.cfg.mp_detection_confidence,
            min_tracking_confidence=self.cfg.mp_tracking_confidence,
        )

    # ──────────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────────

    def extract_from_video(self, video_path: str) -> np.ndarray:
        """
        Extract a fixed-length landmark sequence from a single video.

        Returns
        -------
        np.ndarray
            Shape ``(sequence_length, num_landmarks)``.
        """
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise ValueError(f"Cannot open video: {video_path}")

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_indices = self._compute_sample_indices(total_frames)
        target_set = set(frame_indices)

        landmarks_seq: list = []
        current_frame = 0

        while cap.isOpened() and len(landmarks_seq) < self.cfg.sequence_length:
            ret, frame = cap.read()
            if not ret:
                break
            if current_frame in target_set:
                ts = int(cap.get(cv2.CAP_PROP_POS_MSEC))
                lm = self._extract_frame_landmarks(frame, timestamp_ms=ts)
                landmarks_seq.append(lm)
            current_frame += 1

        cap.release()

        # Pad short sequences with zeros
        while len(landmarks_seq) < self.cfg.sequence_length:
            landmarks_seq.append(np.zeros(self.cfg.num_landmarks, dtype=np.float32))

        return np.array(landmarks_seq[: self.cfg.sequence_length], dtype=np.float32)

    def extract_from_frame(self, frame: np.ndarray, timestamp_ms: Optional[int] = None) -> np.ndarray:
        """
        Extract landmarks from a single BGR frame.

        Returns
        -------
        np.ndarray
            Shape ``(num_landmarks,)`` — zeros if no hand detected.
        """
        return self._extract_frame_landmarks(frame, timestamp_ms=timestamp_ms)

    def detect_hands(self, frame: np.ndarray, timestamp_ms: Optional[int] = None) -> HandDetection:
        """Return the raw hand detections for drawing / cropping."""
        return self._hands.detect(frame, timestamp_ms=timestamp_ms)

    # ──────────────────────────────────────────────────────────────────────
    # Frame-level extraction
    # ──────────────────────────────────────────────────────────────────────

    def _extract_frame_landmarks(self, frame: np.ndarray, timestamp_ms: Optional[int] = None) -> np.ndarray:
        results = self._hands.detect(frame, timestamp_ms=timestamp_ms)

        if self.cfg.use_both_hands:
            return self._extract_dual_hand(results)
        return self._extract_single_hand(results)

    def _extract_single_hand(self, results: HandDetection) -> np.ndarray:
        """Original single-hand path with wrist-relative normalization."""
        if results.hands:
            raw = results.hands[0].landmarks.flatten()
            return self._normalize_hand(raw)
        return np.zeros(63, dtype=np.float32)

    def _extract_dual_hand(self, results: HandDetection) -> np.ndarray:
        """
        Extract both hands, assign to left/right slots via MediaPipe
        handedness, normalize each independently, and compute inter-hand
        relative features from raw image-space coordinates.
        """
        left_raw: Optional[np.ndarray] = None
        right_raw: Optional[np.ndarray] = None

        for hand in results.hands:
            if hand.score < 0.5:
                continue
            raw = hand.landmarks.flatten()
            if hand.label == "Left":
                left_raw = raw
            else:
                right_raw = raw

        left = self._normalize_hand(left_raw) if left_raw is not None \
            else np.zeros(63, dtype=np.float32)
        right = self._normalize_hand(right_raw) if right_raw is not None \
            else np.zeros(63, dtype=np.float32)

        if not self.cfg.use_inter_hand_features:
            return np.concatenate([left, right]).astype(np.float32)

        # Inter-hand features use *raw* image-space coords so that the
        # absolute spatial relationship between the two hands is preserved
        # (after per-hand normalization, each wrist is at the origin,
        # so relative positions can only be derived from raw coords).
        if left_raw is not None and right_raw is not None:
            lw = left_raw[:3]                                  # left wrist
            rw = right_raw[:3]                                 # right wrist
            li = left_raw[_LANDMARK_INDEX_TIP * 3: _LANDMARK_INDEX_TIP * 3 + 3]
            ri = right_raw[_LANDMARK_INDEX_TIP * 3: _LANDMARK_INDEX_TIP * 3 + 3]
            inter = np.concatenate([rw - lw, ri - li])        # (6,)
        else:
            inter = np.zeros(6, dtype=np.float32)

        return np.concatenate([left, right, inter]).astype(np.float32)

    # ──────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _normalize_hand(landmarks: np.ndarray) -> np.ndarray:
        """
        Wrist-relative, scale-invariant normalization.

        1. Translate all 21 landmarks so wrist (landmark 0) is at origin.
        2. Divide by the maximum distance from the wrist to any other landmark.

        This removes the effect of hand position and size in the frame,
        leaving only the *shape* of the gesture.
        """
        pts = landmarks.reshape(21, 3)
        wrist = pts[0].copy()
        pts = pts - wrist

        # Use max distance from wrist to any other landmark as scale factor
        distances = np.linalg.norm(pts[1:], axis=1)
        scale = distances.max()
        if scale > 1e-6:
            pts = pts / scale

        return pts.flatten().astype(np.float32)

    def _compute_sample_indices(self, total_frames: int) -> list:
        """Uniformly sample `sequence_length` frame indices from the video."""
        seq_len = self.cfg.sequence_length
        if total_frames <= 0:
            return list(range(seq_len))
        if total_frames <= seq_len:
            return list(range(total_frames))
        return list(np.linspace(0, total_frames - 1, seq_len, dtype=int))

    def close(self):
        """Release MediaPipe resources."""
        self._hands.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
